#include <stdio.h>
#include <vcl.h>
#pragma hdrstop
#include "mmsystem.h"
#include "Unit1.h"
#include "Unit2.h"
#include "IniFiles.hpp"
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
TIniFile *Ini = new TIniFile(ExtractFilePath (Application->ExeName )+"options.ini"); //start z ustawieniami z pliku
Graphics::TBitmap*Enemy1;//bialy czolg (����� ����)
Graphics::TBitmap*BG;// Back Buffer(������ ������)

Graphics::TBitmap*ball;//czym strzelamy domyslnie (����)

Graphics::TBitmap*tank;//czolg gracza 1 (���� �����a 1)
Graphics::TBitmap*tank2;//czolg gracza 2 (���� �����a 2)

Graphics::TBitmap*wall1;//sciana z drewna (��������� ������)
Graphics::TBitmap*wall2;//sciana cegla rodzaj 1 (��������� ������)
Graphics::TBitmap*wall4;//sciana cegla rodzaj 2 (��������� ������ 2)
Graphics::TBitmap*wall5;//sciana cegla po trafieniu 
Graphics::TBitmap*wall3;//sciana z zelaza � niemozliwie rozbic 
Graphics::TBitmap*water;//przeszkoda typu woda 
Graphics::TBitmap*tree;//drzewo widok z gory - przejezdne
Graphics::TBitmap*ice;//lod � hamowanie stopniowe
Graphics::TBitmap*base;//orzel bazy
Graphics::TBitmap*enemy_base; // miejsce respawnu wroga :)
Graphics::TBitmap*bonus;//ikona bonusu 
Graphics::TBitmap*background;//tlo (���)
Graphics::TBitmap*boom;//eksplodacja tanka po trafieniu
Graphics::TBitmap*comet;//upgrade zbroja 
bool LeftKeyDown,RightKeyDown,UpKeyDown,DownKeyDown;  //sterowanie dla 1 gracza
bool LeftKeyDownA,RightKeyDownA,UpKeyDownA,DownKeyDownA;     //sterowanie dla 2 gracza
int PosX,PosY,Speed,PosSX[2],PosSY[2];  //pozycja 1 gracza, koordynata, szybkosc
int PosXA,PosYA,SpeedA,PosSXA[2],PosSYA[2];  //pozycja dla 2 gracza
int a[100][100];//matryca mapki
int see,way;  //gdzie �patrzy� czolg gracza 1 
int seeA,wayA; //to samo dla 2
bool bon;//bonus-polepszenie
bool TwoPlayers;//czy bedzie 2 gracz
int BonusX,BonusY,Bpic;//koordynaty bonusu - random
int BallX,BallY,BallSpeed;  //koordynaty pocisku gracza 1
int BallXA,BallYA,BallSpeedA; // koordynaty pocisku gracza 2 
int CometX,CometY,CometSpeed;// koordynaty pocisku polepszonego gracza 
bool FireOn,FireOff; //Fireoff zakaz strzalu,FireOn wskazuje kierunek pocisku
bool FireOnA,FireOffA;
int lvl=1;//inicjalizacja pierwszej mapki
int colT=0;//ilo?? czolgow przeciwnika
int BOT1;  //
int life=3;//zycie dla 1
int lifeA=3;//zycie dla 2
int leftT;//ile pozostalo czolgow do zniszczenia
int boomX,boomY,pic;//koordynaty eksplozji
bool bbb;//wlaczamy czy nie eksplozje
bool music,sound;//wlaczmy/wylaczamy muzyke i dzwieki
int tt;//licznik la generowania minionikow
int score;//record, liczy sie= score*ttime
int ttime;//czas gracza w gre
int kill,last;//zabil, zostalo
bool pause,gameover,win;//dla wlaczania pauzy, przegrania i zwycienstwa
int weapon;//biezaca zbroja
bool Tice;//sprawdzenie prawidlowosci koordynat
bool TiceA; 

__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{

}

class ETank1  //czolgi wroze, czyli minioniki
{
public:
int PosXE;//pozycja czo?gu po �
int PosYE;// pozycja czo?gu po �
int PosY1E;// pozycja pocisku po �
int PosX1E;// pozycja pocisku po �
int PosYX[2],PosXX[2];
int SpeedT;//szybkosc
int side,sside;//kierunek jazdy
int SpeedBB1;
bool FireBB;
ETank1()
        {
        PosXE=570;
        PosYE=400;
        SpeedT=0;
        }
void moveE ()  //ruch czolgu-miniomiku
        {
        if (side==2){//ruch wlewo
                if(
        (PosXE%30!=0||(a[PosXE/30-1][PosYE/30]==0||a[PosXE/30-1][PosYE/30]==8||a[PosXE/30-1][PosYE/30]==9) &&
        (PosYE%30==0||(a[PosXE/30-1][PosYE/30+1]==0||a[PosXE/30-1][PosYE/30+1]==8||a[PosXE/30-1][PosYE/30+1]==9)))
           )
                {
                PosYX[0]=PosYE;
                PosXX[0]=PosXE;
                PosXE-=SpeedT;
                }
                Enemy1->LoadFromFile("picture\\enemy_leftx30.bmp");
                BG->Canvas->Draw(PosXE,PosYE,Enemy1);
        }
        if (side==3){//ruch wprawo
                if(
        (a[PosXE/30+1][PosYE/30]==0||a[PosXE/30+1][PosYE/30]==8||a[PosXE/30+1][PosYE/30]==9)&&
        (PosYE%30==0||(a[PosXE/30+1][PosYE/30+1]==0||a[PosXE/30+1][PosYE/30+1]==8||a[PosXE/30+1][PosYE/30+1]==9)))
                {
                PosYX[0]=PosYE;
                PosXX[0]=PosXE;
                PosXE+=SpeedT;
                }
                Enemy1->LoadFromFile("picture\\enemy_rightx30.bmp");
                BG->Canvas->Draw(PosXE,PosYE,Enemy1);
        }
        if (side==1){//ruch do dolu        (a[PosXE/30][PosYE/30+1]==0||a[PosXE/30][PosYE/30+1]==8||a[PosXE/30][PosYE/30+1]==9)&&
        (PosXE%30==0||(a[PosXE/30+1][PosYE/30+1]==0||a[PosXE/30+1][PosYE/30+1]==8||a[PosXE/30+1][PosYE/30+1]==9)))
                {
                PosYX[0]=PosYE;
                PosXX[0]=PosXE;
                PosYE+=SpeedT;
                }
                Enemy1->LoadFromFile("picture\\enemy_downx30.bmp");
                BG->Canvas->Draw(PosXE,PosYE,Enemy1);
        }
        if (side==0){//ruch do gory
PosXE/30][PosYE/30-1]==0||a[PosXE/30][PosYE/30-1]==8||a[PosXE/30][PosYE/30-1]==9)&&
        (PosXE%30==0||(a[PosXE/30+1][PosYE/30-1]==0||a[PosXE/30+1][PosYE/30-1]==8||a[PosXE/30+1][PosYE/30-1]==9)))
                {
                PosYX[0]=PosYE;
                PosXX[0]=PosXE;
                PosYE-=SpeedT;
                }
                Enemy1->LoadFromFile("picture\\enemy_upx30.bmp");
                BG->Canvas->Draw(PosXE,PosYE,Enemy1);
        }
}
void RandE ()  //random-generator ruchu dla minionikow
{
        Randomize;
        side = random(5);
        if (side==4)
        {
        if (PosYE<510)side=1;
        if (PosYE>510&&PosXE<270)side=3;
        if (PosYE>510&&PosXE>270)side=2;
        }
}

void RandEB ()
{
SpeedBB1=9;
sside=side;
       if (side==3)
                {
                PosX1E=PosXE+27;
                PosY1E=PosYE+11;
                }
        if (side==2)
                {
                PosX1E=PosXE-2;
                PosY1E=PosYE+11;
                }
        if (side==0)
                {
                PosX1E=PosXE+11;
                PosY1E=PosYE-2;
                }
        if (side==1)
                {
                PosX1E=PosXE+11;
                PosY1E=PosYE+25;
                }
}

void Eball () //strzelanie minionikow
{
if (SpeedBB1>1)FireBB=true; //dozwolamy im strzelac
if (sside==1)PosY1E+=SpeedBB1;
if (sside==0)PosY1E-=SpeedBB1;
if (sside==2)PosX1E-=SpeedBB1;
if (sside==3)PosX1E+=SpeedBB1;
BG->Canvas->Draw(PosX1E,PosY1E,ball);
}

};
ETank1 Tank1[1000];




void __fastcall TForm1::FormCreate(TObject *Sender)
{
FILE *f;
if(f=fopen((ExtractFilePath(Application->ExeName) + "map_"+IntToStr(lvl)+".txt").c_str(),"r"))
for (int i=0;i<20;i++)
{
        for(int j=0;j<=20;j++)
        {
        char t=fgetc(f); //ladujemy mape cyfrowa I co jest co w niej
        switch (t)
        {
        case '0': a[j][i]=0;break;
        case '1': a[j][i]=1;break;
        case '2': a[j][i]=2;break;
        case '3': a[j][i]=3;break;
        case '4': a[j][i]=4;break;
        case '5': a[j][i]=5;break;
        case '6': a[j][i]=6;break;
        case '7': a[j][i]=7;break;
        case '8': a[j][i]=8;break;
        case '9': a[j][i]=9;break;
        }
        }
}
tank = new Graphics::TBitmap(); //czolg gracza 1
tank->LoadFromFile("picture\\tank1.bmp");
tank->Transparent=1;
tank2 = new Graphics::TBitmap();
tank2->LoadFromFile("picture\\tank1a.bmp"); //czolg gracza 2
tank2->Transparent=1;
ball = new Graphics::TBitmap();
ball->LoadFromFile("picture\\Ball.bmp");  //pocisk
base = new Graphics::TBitmap();
base->LoadFromFile("picture\\base.bmp"); //orzel bazy
enemy_base = new Graphics::TBitmap();
enemy_base->LoadFromFile("picture\\enemy_base.bmp"); //miejsce generacji minionikow
Enemy1 = new Graphics::TBitmap();
Enemy1->LoadFromFile("picture\\enemy_upx30.bmp");
wall1 = new Graphics::TBitmap();
wall1->LoadFromFile("picture\\wall1.bmp");
wall2 = new Graphics::TBitmap();
wall2->LoadFromFile("picture\\wall2.bmp");
wall3 = new Graphics::TBitmap();
wall3->LoadFromFile("picture\\wall3.bmp");
wall4 = new Graphics::TBitmap();
wall4->LoadFromFile("picture\\wall4.bmp");
wall5 = new Graphics::TBitmap();
wall5->LoadFromFile("picture\\wall5.bmp");
water = new Graphics::TBitmap();
water->LoadFromFile("picture\\water.bmp");
tree = new Graphics::TBitmap();
tree->LoadFromFile("picture\\tree.bmp");
tree->Transparent=1;
ice = new Graphics::TBitmap();
ice->LoadFromFile("picture\\ice.bmp");
comet = new Graphics::TBitmap();
comet->LoadFromFile("picture\\comet_right.bmp");
comet->Transparent=1;
boom = new Graphics::TBitmap();
bonus = new Graphics::TBitmap();
bonus->Transparent=1;
background = new Graphics::TBitmap();
background->LoadFromFile("picture\\background.bmp");
FireOn=false;
BG = new Graphics::TBitmap(); //Back Buffer
BG->Width=Form1->Width;
BG->Height=Form1->Height;
//-------Ustawienia ogolne-------
PosX=210;
PosY=540;
BonusX=-100;
BonusY=-100;
Speed=5;
see=1;
BallSpeed=0;
BallX=0;
BallY=0;
CometX=0;
CometY=0;
pic=1;
BOT1=5;
tt=0;
score=0;
ttime=0;
kill=0;
last=BOT1;
bon=true;
weapon=1;
//----ustawienia dla gracza 2, o ile bedzie------
PosXA=330;
PosYA=540;
SpeedA=5;
seeA=1;
BallSpeedA=0;
BallXA=0;
BallYA=0;
}


void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
Tice=true;
sound=Ini->ReadBool("Settings","Sound","def");  //ustawiamy dzieki I muzyke
music=Ini->ReadBool("Settings","music","def");
TwoPlayers=Ini->ReadBool("Settings","Twoplayers","def");
if (music)mciSendString("play sound\\bc_loop_16bit.wav ", 0, 0,0); //skad brac dziwek
draw();
BG->Canvas->Draw(BonusX,BonusY,bonus);
if (bbb)
{
boom->LoadFromFile("picture\\explosion"+IntToStr(pic)+".bmp"); / robimy animowana eksplozje
pic++;
	if (pic==15)
	{
	bbb=false;
	boom->LoadFromFile("picture\\background.bmp"); //ustawienia tla
	pic=1;
	}
	BG->Canvas->Draw(boomX,boomY,boom);
}

for (int i=0; i<colT; i++){
        Tank1[i].moveE();
        Tank1[i].Eball();
        }
if (last==0)Nextlvl();  //przecodzimy na nastepny poziom
movetank();
if (TwoPlayers) movetankA();
dmg();
testwall();
TestWallBot();
CollisionTanks();
GameOver();

if(Tice){if(PosX%5)PosX++;if(PosY%5)PosY++;}
tank->LoadFromFile("picture\\tank"+IntToStr(see)+".bmp");

if(TiceA){if(PosXA%5)PosXA++;if(PosYA%5)PosYA++;}
if (TwoPlayers)tank2->LoadFromFile("picture\\tank"+IntToStr(seeA)+"a.bmp");

BG->Canvas->Draw(PosX,PosY,tank);
if (TwoPlayers)BG->Canvas->Draw(PosXA,PosYA,tank2);

if ( weapon==1)Ball();
if (TwoPlayers==true )BallA();
if (weapon==2)Comet();
BG->Canvas->Draw(120,30,enemy_base);
BG->Canvas->Draw(360,30,enemy_base);
DrawTree();
//-------robimy tabele sprawa, czyli score, life itd-----
AnsiString sscore ;
if (score==0)sscore="00000";
if (score<1000&&score>=100)sscore="00"+IntToStr(score);
if (score<10000&&score>=1000)sscore="0"+IntToStr(score);
if (score>10000)sscore=IntToStr(score);
AnsiString weapons;
if (weapon==1)weapons="bullet";
if (weapon==2)weapons="comet";
BG->Canvas->Brush->Color=clBlack;
BG->Canvas->Rectangle(600,0,800,630);
AddFontResourceA("font\\digital-7.ttf"); //ccionka dla tabeli
BG->Canvas->Font->Name="Digital-7";
BG->Canvas->Font->Size=30;
BG->Canvas->Font->Color=clGray;
BG->Canvas->TextOutA(Form1->Width-150,30,"Score:");
BG->Canvas->TextOutA(Form1->Width-150,80,sscore);
BG->Canvas->TextOutA(Form1->Width-200,150,"Time: ");
BG->Canvas->TextOutA(Form1->Width-120,150,ttime);
BG->Canvas->Font->Color=clRed;
BG->Canvas->TextOutA(Form1->Width-200,200,"Killed: ");
BG->Canvas->TextOutA(Form1->Width-80,200,kill);
BG->Canvas->TextOutA(Form1->Width-200,250,"Last: ");
BG->Canvas->TextOutA(Form1->Width-110,250,last);
if (TwoPlayers){
BG->Canvas->Font->Color=clBlue;
BG->Canvas->TextOutA(Form1->Width-150,500,"Life: ");
BG->Canvas->TextOutA(Form1->Width-80,500,lifeA);
}
BG->Canvas->Font->Color=clGreen;
BG->Canvas->TextOutA(Form1->Width-150,550,"Life: ");
BG->Canvas->TextOutA(Form1->Width-80,550,life);
BG->Canvas->Font->Color=clGray;
BG->Canvas->Font->Size=20;
BG->Canvas->TextOutA(Form1->Width-200,450,"Weapon: ");
BG->Canvas->TextOutA(Form1->Width-115,450,weapons);
BG->Canvas->Font->Size=30;
BG->Canvas->TextOutA(Form1->Width-200,400,"lvl: ");
BG->Canvas->TextOutA(Form1->Width-125,400,lvl);
Form1->Canvas->Draw(0,0,BG);

}
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)  //jak opracowujemy nacisk
{
if(Key==VK_RIGHT){RightKeyDown=true;LeftKeyDown=false;UpKeyDown=false;DownKeyDown=false;see=4;}
if(Key==VK_LEFT){LeftKeyDown=true;RightKeyDown=false;UpKeyDown=false;DownKeyDown=false;see=3;}
if(Key==VK_UP){UpKeyDown=true;DownKeyDown=false;RightKeyDown=false;LeftKeyDown=false;see=1;}
if(Key==VK_DOWN){DownKeyDown=true;UpKeyDown=false;LeftKeyDown=false;RightKeyDown=false;see=2;}
if (FireOff==False)
{
if(Key==VK_SPACE)
{
if (weapon==1){
        if (sound)mciSendString("play sound\\bc_shoot.wav ", 0, 0,0); /dzwiek strzalu
        way=see;
        BallSpeed=8;
        FireOff=true;

                if (see==4)
                        {
                        BallX=PosX+27;
                        BallY=PosY+11;
                        }
                if (see==3)
                        {
                        BallX=PosX-2;
                        BallY=PosY+11;
                        }
                if (see==1)
                        {
                        BallX=PosX+11;
                        BallY=PosY-2;
                        }
                if (see==2)
                        {
                        BallX=PosX+11;
                        BallY=PosY+25;
                        }
                }
if (weapon==2) {
        if (sound)mciSendString("play sound\\bc_shoot.wav ", 0, 0,0); //strzal polepszony
        way=see;
        CometSpeed=7;
        FireOff=true;

                if (see==4)
                        {
                        comet->LoadFromFile("picture\\comet_right.bmp");
                        CometX=PosX+27;
                        CometY=PosY+11;
                        }
                if (see==3)
                        {
                        comet->LoadFromFile("picture\\comet_left.bmp");
                        CometX=PosX-2;
                        CometY=PosY+11;
                        }
                if (see==1)
                        {
                        comet->LoadFromFile("picture\\comet_up.bmp");
                        CometX=PosX+11;
                        CometY=PosY-2;
                        }
                if (see==2)
                        {
                        comet->LoadFromFile("picture\\comet_down.bmp");
                        CometX=PosX+11;
                        CometY=PosY+25;
                        }
                }
             }
        }
if (FireOffA==False)
{
if(Key==VK_CONTROL)
{

        if (sound)mciSendString("play sound\\bc_shoot.wav ", 0, 0,0);
        wayA=seeA;
        BallSpeedA=8;
        FireOffA=true;
                if (seeA==4)
                        {
                        BallXA=PosXA+27;
                        BallYA=PosYA+11;
                        }
                if (seeA==3)
                        {
                        BallXA=PosXA-2;
                        BallYA=PosYA+11;
                        }
                if (seeA==1)
                        {
                        BallXA=PosXA+11;
                        BallYA=PosYA-2;
                        }
                if (seeA==2)
                        {
                        BallXA=PosXA+11;
                        BallYA=PosYA+25;
                        }
        }

}
//----------------ruch dla gracza 2-------------------------------
if(Key=='D'){RightKeyDownA=true;LeftKeyDownA=false;UpKeyDownA=false;DownKeyDownA=false;seeA=4;}
if(Key=='A'){LeftKeyDownA=true;RightKeyDownA=false;UpKeyDownA=false;DownKeyDownA=false;seeA=3;}
if(Key=='W'){UpKeyDownA=true;DownKeyDownA=false;RightKeyDownA=false;LeftKeyDownA=false;seeA=1;}
if(Key=='S'){DownKeyDownA=true;UpKeyDownA=false;LeftKeyDownA=false;RightKeyDownA=false;seeA=2;}


if (Key==VK_PAUSE) Pause();
//if  (Key==VK_F4)life--;
if (Key==VK_F2) NewGame();
if (Key==VK_F5)Nextlvl();
}


void TForm1::movetank() //jak ten czolg bedzie odmalowany
{
if (LeftKeyDown)
        {
        if(
        (PosX%30!=0||(a[PosX/30-1][PosY/30]==0||a[PosX/30-1][PosY/30]==8||a[PosX/30-1][PosY/30]==9) &&
        (PosY%30==0||(a[PosX/30-1][PosY/30+1]==0||a[PosX/30-1][PosY/30+1]==8||a[PosX/30-1][PosY/30+1]==9))))
                {
                PosSY[0]=PosY;
                PosSX[0]=PosX;
                PosX-=Speed;
                }
        BG->Canvas->Draw(PosX,PosY,tank);
        if (FireOn==False){way=3;}
        }
 if (RightKeyDown)
        {
        if(
        (a[PosX/30+1][PosY/30]==0||a[PosX/30+1][PosY/30]==8||a[PosX/30+1][PosY/30]==9)&&
        (PosY%30==0||(a[PosX/30+1][PosY/30+1]==0||a[PosX/30+1][PosY/30+1]==8||a[PosX/30+1][PosY/30+1]==9)))
                {
                PosSY[0]=PosY;
                PosSX[0]=PosX;
                PosX+=Speed;
                }
        BG->Canvas->Draw(PosX,PosY,tank);
        if (FireOn==False){way=4;}
        }
 if (DownKeyDown)
        {
        if((a[PosX/30][PosY/30+1]==0||a[PosX/30][PosY/30+1]==8||a[PosX/30][PosY/30+1]==9)
        && (PosX%30==0||(a[PosX/30+1][PosY/30+1]==0||a[PosX/30+1][PosY/30+1]==8||a[PosX/30+1][PosY/30+1]==9)))
                {
                PosSY[0]=PosY;
                PosSX[0]=PosX;
                PosY+=Speed;
                }
        BG->Canvas->Draw(PosX,PosY,tank);
        if (FireOn==False){way=2;}
        }
 if (UpKeyDown)
        {
        if(PosY%30!=0||(a[PosX/30][PosY/30-1]==0||a[PosX/30][PosY/30-1]==8||a[PosX/30][PosY/30-1]==9)
        &&(PosX%30==0||(a[PosX/30+1][PosY/30-1]==0||a[PosX/30+1][PosY/30-1]==8||a[PosX/30+1][PosY/30-1]==9)))
                {
                PosSY[0]=PosY;
                PosSX[0]=PosX;
                PosY-=Speed;
                }
        BG->Canvas->Draw(PosX,PosY,tank);
        if (FireOn==False){way=1;}
        }
}

//---------------------------------------------------------------------------
void TForm1::movetankA()
{
if (LeftKeyDownA)
        {
        if(
        (PosXA%30!=0||(a[PosXA/30-1][PosYA/30]==0||a[PosXA/30-1][PosYA/30]==8||a[PosXA/30-1][PosYA/30]==9) &&
        (PosYA%30==0||(a[PosXA/30-1][PosYA/30+1]==0||a[PosXA/30-1][PosYA/30+1]==8||a[PosXA/30-1][PosYA/30+1]==9))))
                {
                PosSYA[0]=PosYA;
                PosSXA[0]=PosXA;
                PosXA-=SpeedA;
                }
        BG->Canvas->Draw(PosXA,PosYA,tank2);
        if (FireOnA==False){wayA=3;}
        }
if (RightKeyDownA)
        {
        if(
        (a[PosXA/30+1][PosYA/30]==0||a[PosXA/30+1][PosYA/30]==8||a[PosXA/30+1][PosYA/30]==9)&&
        (PosYA%30==0||(a[PosXA/30+1][PosYA/30+1]==0||a[PosXA/30+1][PosYA/30+1]==8||a[PosXA/30+1][PosYA/30+1]==9)))
                {
                PosSYA[0]=PosYA;
                PosSXA[0]=PosXA;
                PosXA+=SpeedA;
                }
        BG->Canvas->Draw(PosXA,PosYA,tank2);
        if (FireOnA==False){wayA=4;}
        }
if (DownKeyDownA)
        {
        if(
        (a[PosXA/30][PosYA/30+1]==0||a[PosXA/30][PosYA/30+1]==8||a[PosXA/30][PosYA/30+1]==9)
        && (PosXA%30==0||(a[PosXA/30+1][PosYA/30+1]==0||a[PosXA/30+1][PosYA/30+1]==8||a[PosXA/30+1][PosYA/30+1]==9)))
                {
                PosSYA[0]=PosYA;
                PosSXA[0]=PosXA;
                PosYA+=SpeedA;
                }
        BG->Canvas->Draw(PosXA,PosYA,tank2);
        if (FireOnA==False){wayA=2;}
        }
if (UpKeyDownA)
        {
        if(PosYA%30!=0||(a[PosXA/30][PosYA/30-1]==0||a[PosXA/30][PosYA/30-1]==8||a[PosXA/30][PosYA/30-1]==9)
        &&(PosXA%30==0||(a[PosXA/30+1][PosYA/30-1]==0||a[PosXA/30+1][PosYA/30-1]==8||a[PosXA/30+1][PosYA/30-1]==9)))
                {
                PosSYA[0]=PosYA;
                PosSXA[0]=PosXA;
                PosYA-=SpeedA;
                }
        BG->Canvas->Draw(PosXA,PosYA,tank2);
        if (FireOnA==False){wayA=1;}
        }
}

void __fastcall TForm1::FormKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
//gracz1
if(Key==VK_RIGHT){RightKeyDown=false;}
if(Key==VK_LEFT){LeftKeyDown=false;}
if(Key==VK_DOWN){DownKeyDown=false;}
if(Key==VK_UP){UpKeyDown=false;}
//gracz2
if(Key=='D'){RightKeyDownA=false;}
if(Key=='A'){LeftKeyDownA=false;}
if(Key=='W'){UpKeyDownA=false;}
if(Key=='S'){DownKeyDownA=false;}
}


void TForm1::draw()
{
        for (int i=0;i<20;i++)
        {
                for (int j=0;j<20;j++)
                {
                        switch (a[i][j])
                        {
                        case 0: BG->Canvas->Draw(i*30,j*30,background) ; break;
                        case 1: BG->Canvas->Draw(i*30,j*30,wall3) ; break;
                        case 2: BG->Canvas->Draw(i*30,j*30,wall4)  ;break;
                        case 3: BG->Canvas->Draw(i*30,j*30,wall1)  ;break;
                        case 4: BG->Canvas->Draw(i*30,j*30,wall4)  ;break;
                        case 5: BG->Canvas->Draw(i*30,j*30,wall5)  ;break;
                        case 6: BG->Canvas->Draw(i*30,j*30,base)  ;break;
                        case 7: BG->Canvas->Draw(i*30,j*30,water)  ;break;
                        case 9: BG->Canvas->Draw(i*30,j*30,ice)  ;break;
                        }
                }
        }
}


void TForm1::DrawTree()
{
        for (int i=0;i<20;i++)
        {
                for (int j=0;j<20;j++)
                {
                        switch (a[i][j])
                        {
                        case 8: BG->Canvas->Draw(i*30,j*30,tree)  ;break;
                        }
                }
        }
}

void TForm1::testwall()   //malujemy kolkami nasze mapki, gdzie i co
{      RECT Rtank=Rect(PosX,PosY,PosX+30,PosY+30);
       RECT RtankA=Rect(PosXA,PosYA,PosXA+30,PosYA+30);
       RECT Rect1=Rect(BallX,BallY,BallX+9,BallY+9);
       RECT RBallA=Rect(BallXA,BallYA,BallXA+9,BallYA+9);
       RECT RComet=Rect(CometX,CometY,CometX+10,CometY+10);
       RECT Rect0=Rect(0,0,0,0);
        for (int i=0;i<20;i++)
        {
                for (int j=0;j<20;j++)
                {
                        switch (a[i][j])
                        {
                        case 1: { RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                {
                                FireOff=false;
                                FireOn=false;
                                BallX=800;
                                BallY=500;
                                BallSpeed=0;
                                }if (IntersectRect(&Rect0,&RBallA,&Rect2))
                                {
                                FireOffA=false;
                                FireOnA=false;
                                BallXA=800;
                                BallYA=500;
                                BallSpeedA=0;
                                }
                                if (IntersectRect(&Rect0,&RComet,&Rect2))
                                {
                                FireOff=false;
                                FireOn=false;
                                CometX=800;
                                CometY=500;
                                CometSpeed=0;
                                }break;

                                }
                        case 2: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                {
                                a[i][j]=4;
                                FireOff=false;
                                FireOn=false;
                                BallX=800;
                                BallY=500;
                                BallSpeed=0;
                                }
                                if (IntersectRect(&Rect0,&RBallA,&Rect2))
                                {
                                a[i][j]=4;
                                FireOffA=false;
                                FireOnA=false;
                                BallXA=800;
                                BallYA=500;
                                BallSpeedA=0;
                                }
                                if (IntersectRect(&Rect0,&RComet,&Rect2))
                                {
                                a[i][j]=0;
                                FireOff=false;
                                FireOn=false;
                                CometX=800;
                                CometY=500;
                                CometSpeed=0;
                                }break;
                                }
                         case 3: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                {
                                a[i][j]=0;
                                FireOff=false;
                                FireOn=false;
                                BallX=800;
                                BallY=500;
                                BallSpeed=0;
                                }
                                if (IntersectRect(&Rect0,&RBallA,&Rect2))
                                {
                                a[i][j]=0;
                                FireOffA=false;
                                FireOnA=false;
                                BallXA=800;
                                BallYA=500;
                                BallSpeedA=0;
                                }
                                if (IntersectRect(&Rect0,&RComet,&Rect2))
                                {
                                a[i][j]=0;
                                FireOff=false;
                                FireOn=false;
                                CometX=800;
                                CometY=500;
                                CometSpeed=0;
                                }break;
                                }
                         case 4: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                {
                                a[i][j]=5;
                                FireOff=false;
                                FireOn=false;
                                BallX=800;
                                BallY=500;
                                BallSpeed=0;
                                }
                                if (IntersectRect(&Rect0,&RBallA,&Rect2))
                                {
                                a[i][j]=5;
                                FireOffA=false;
                                FireOnA=false;
                                BallXA=800;
                                BallYA=500;
                                BallSpeedA=0;
                                }
                                if (IntersectRect(&Rect0,&RComet,&Rect2))
                                {
                                a[i][j]=0;
                                FireOff=false;
                                FireOn=false;
                                CometX=800;
                                CometY=500;
                                CometSpeed=0;
                                }break;
                                }
                          case 5: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                {
                                a[i][j]=0;
                                FireOff=false;
                                FireOn=false;
                                BallX=800;
                                BallY=500;
                                BallSpeed=0;
                                }
                                if (IntersectRect(&Rect0,&RBallA,&Rect2))
                                {
                                a[i][j]=0;
                                FireOffA=false;
                                FireOnA=false;
                                BallXA=800;
                                BallYA=500;
                                BallSpeedA=0;
                                }
                                if (IntersectRect(&Rect0,&RComet,&Rect2))
                                {
                                a[i][j]=0;
                                FireOff=false;
                                FireOn=false;
                                CometX=800;
                                CometY=500;
                                CometSpeed=0;
                                }break;
                                }
                          case 6:{RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                {
                                life=-1;
                                FireOff=false;
                                FireOn=false;
                                BallX=800;
                                BallY=500;
                                BallSpeed=0;
                                }
                                if (IntersectRect(&Rect0,&RBallA,&Rect2))
                                {
                                life=-1;
                                FireOffA=false;
                                FireOnA=false;
                                BallXA=800;
                                BallYA=500;
                                BallSpeedA=0;
                                }
                                if (IntersectRect(&Rect0,&RComet,&Rect2))
                                {
                                life=-1;
                                FireOff=false;
                                FireOn=false;
                                CometX=800;
                                CometY=500;
                                CometSpeed=0;
                                }break;
                                }
                           case 9:{RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                            if(IntersectRect(&Rect0,&RtankA,&Rect2))
                           {SpeedA=2;
                           if(LeftKeyDownA==true && PosXA%5){if(PosXA%5==1)PosXA--;}
                           if(RightKeyDownA==true && PosXA%5){if(PosXA%5==4)PosXA++;}
                           if(UpKeyDownA==true && PosYA%5){if(PosYA%5==1)PosYA--;}
                           if(DownKeyDownA==true && PosYA%5!=0){if(PosYA%5==4)PosYA++;}
                           }
                           if(IntersectRect(&Rect0,&Rtank,&Rect2))
                           {Speed=2;Tice=false;
                           if(LeftKeyDown==true && PosX%5){if(PosX%5==1)PosX--;}
                           if(RightKeyDown==true && PosX%5){if(PosX%5==4)PosX++;}
                           if(UpKeyDown==true && PosY%5){if(PosY%5==1)PosY--;}
                           if(DownKeyDown==true && PosY%5!=0){if(PosY%5==4)PosY++;}

                          }break;
                               }
                        }
                }
        }
}
//-------------------------------------------------------------------------
void TForm1::Ball() //strzal
{
if (way==4)
        {
        FireOn=True;
        BallX+=BallSpeed;
        }
if (way==3)
        {
        FireOn=True;
        BallX-=BallSpeed;
        }
if (way==1)
        {
        FireOn=True;
        BallY-=BallSpeed;
        }
if (way==2)
        {
        FireOn=True;
        BallY+=BallSpeed;
        }
        BG->Canvas->Draw(BallX,BallY,ball);
}



void TForm1::BallA() //strzal dla drugiego gracza
{
if (wayA==4)
        {
        FireOnA=True;
        BallXA+=BallSpeedA;
        }
if (wayA==3)
        {
        FireOnA=True;
        BallXA-=BallSpeedA;
        }
if (wayA==1)
        {
        FireOnA=True;
        BallYA-=BallSpeedA;
        }
if (wayA==2)
        {
        FireOnA=True;
        BallYA+=BallSpeedA;
        }
        BG->Canvas->Draw(BallXA,BallYA,ball);
}



void TForm1::Comet()  //strzal polepszony predkosc
{
if (way==4)
        {
        FireOn=True;
        CometX+=CometSpeed;
        }
if (way==3)
        {
        FireOn=True;
        CometX-=CometSpeed;
        }
if (way==1)
        {
        FireOn=True;
        CometY-=CometSpeed;
        }
if (way==2)
        {
        FireOn=True;
        CometY+=CometSpeed;
        }
        BG->Canvas->Draw(CometX,CometY,comet);
}


void TForm1::dmg()  //zwiekszamy damage
{
RECT R0=Rect(0,0,0,0);
RECT Rect1=Rect(PosX,PosY,PosX+30,PosY+30);
RECT Rect2=Rect(BallX,BallY,BallX+9,BallY+9);
RECT Rcomet=Rect(CometX,CometY,CometX+10,CometY+10);
RECT RBonus=Rect(BonusX,BonusY,BonusX+30,BonusY+30);
RECT RBallA=Rect(BallXA,BallYA,BallXA+9,BallYA+9);
RECT RTankA=Rect(PosXA,PosYA,PosXA+30,PosYA+30);
if(IntersectRect(&R0,&Rect1,&RBonus))
{
if (Bpic==0){
BonusX=-100;
if (weapon<2)
weapon++;}
if(Bpic==1){
BonusX=-100;
life++;
}
}

for (int i=0;i<BOT1;i++){
RECT REtank=Rect(Tank1[i].PosXE,Tank1[i].PosYE,Tank1[i].PosXE+30,Tank1[i].PosYE+30);
RECT RShot=Rect(Tank1[i].PosX1E,Tank1[i].PosY1E,Tank1[i].PosX1E+9,Tank1[i].PosY1E+9);
RECT Rect0=Rect(0,0,0,0);
if(IntersectRect(&Rect0,&Rect2,&REtank))  //kolizja pocisku z przeciwnikiem
{
kill++;last--;
score+=100+ttime*10;
boomX=Tank1[i].PosXE;
boomY=Tank1[i].PosYE;
bbb=true;
Tank1[i].PosXE=-100;
Tank1[i].PosYE=-100;
Tank1[i].PosXX[0]=Tank1[i].PosXE;
Tank1[i].PosYX[0]=Tank1[i].PosYE;
Tank1[i].SpeedT=0;
if(sound)mciSendString("play sound\\bc_crash.wav ", 0, 0,0);
BallSpeed =0;
BallX=0;
BallY=0;
}
if(IntersectRect(&Rect0,&RBallA,&REtank))  //to samo oczywiscie I dla drugiego gracza
{
kill++;last--;
score+=100+ttime*10;
boomX=Tank1[i].PosXE;
boomY=Tank1[i].PosYE;
bbb=true;
Tank1[i].PosXE=-100;
Tank1[i].PosYE=-100;
Tank1[i].PosXX[0]=Tank1[i].PosXE;
Tank1[i].PosYX[0]=Tank1[i].PosYE;
Tank1[i].SpeedT=0;
if(sound)mciSendString("play sound\\bc_crash.wav ", 0, 0,0);
BallSpeedA =0;
BallXA=0;
BallYA=0;
}
if (IntersectRect(&Rect0,&RShot,&RBallA)) //kolizja pocisku z pociskiem minionika
{
FireOffA=false;
FireOnA=false;
Tank1[i].PosX1E=-100;
Tank1[i].PosY1E=-100;
Tank1[i].SpeedBB1=0;
BallXA=-200;
BallYA=-200;
BallSpeedA =0;
}
if(IntersectRect(&Rect0,&RShot,&RTankA)) //trafienie w nas
{
weapon=1;
Tank1[i].PosX1E=-1000;
Tank1[i].PosY1E=-1000;
PosXA=330;
PosYA=540;
BallXA=-400;
BallYA=-400;
CometX=-400;CometY=-400;
PosSXA[0]=210;
PosSYA[0]=540;
lifeA--;
}
if(IntersectRect(&Rect0,&Rcomet,&REtank))  //kolizja strzalu polepszonego z minionikiem
{
kill++;last--;
score+=100+ttime*50;
boomX=Tank1[i].PosXE;
boomY=Tank1[i].PosYE;
bbb=true;
Tank1[i].PosXE=-100;
Tank1[i].PosYE=-100;
Tank1[i].PosXX[0]=Tank1[i].PosXE;
Tank1[i].PosYX[0]=Tank1[i].PosYE;
Tank1[i].SpeedT=0;
if(sound)mciSendString("play sound\\bc_crash.wav ", 0, 0,0);
CometSpeed =0;
CometX=0;
CometY=0;
}

if (IntersectRect(&Rect0,&RShot,&Rect2))
{

FireOff=false;
FireOn=false;
Tank1[i].PosX1E=-100;
Tank1[i].PosY1E=-100;
Tank1[i].SpeedBB1=0;
BallX=-200;
BallY=-200;
BallSpeed =0;
}
if(IntersectRect(&Rect0,&RShot,&Rect1)) //trafienie w nas 2
{
life--;
weapon=1;
Tank1[i].PosX1E=1000;
Tank1[i].PosY1E=1000;
PosX=210;
PosY=540;
PosSX[0]=210;
PosSY[0]=540;
}

if(IntersectRect(&Rect0,&Rect1,&REtank)) //kolizja z minionikiem � po prostu hamujemy I tyle
{ if ((Tank1[i].PosXE>110&&Tank1[i].PosXE<160&&Tank1[i].PosYE<60)||(Tank1[i].PosXE>350&&Tank1[i].PosXE<400&&Tank1[i].PosYE<60)){}
else{
Speed=0;
        PosX=PosSX[0];
        PosY=PosSY[0];
        Tank1[i].PosXE=Tank1[i].PosXX[0];
        Tank1[i].PosYE=Tank1[i].PosYX[0];
        Tank1[i].RandE();break; }
}
else Speed=5;

if(IntersectRect(&Rect0,&RTankA,&REtank)) //to samo dla drugiegi gracza
{ if ((Tank1[i].PosXE>110&&Tank1[i].PosXE<160&&Tank1[i].PosYE<60)||(Tank1[i].PosXE>350&&Tank1[i].PosXE<400&&Tank1[i].PosYE<60)){}
else{
SpeedA=0;
        PosXA=PosSXA[0];
        PosYA=PosSYA[0];
        Tank1[i].PosXE=Tank1[i].PosXX[0];
        Tank1[i].PosYE=Tank1[i].PosYX[0];
        Tank1[i].RandE();break; }
}
else SpeedA=5;
        
}


}
void __fastcall TForm1::Timer2Timer(TObject *Sender)
{
 for (int i=0;i<BOT1;i++){
Tank1[i].RandE();
 }
 ttime+=1;
}


void __fastcall TForm1::Timer3Timer(TObject *Sender)
{
if (bon)Bonus();  //generujemy bonus
else {
BonusX=-100;
BonusY=-100;
bon=true;
}
if (tt==BOT1)Timer3->Enabled=false;
int r;
r=random(2);
        if (r==1){
                Tank1[tt].PosXE=360;Tank1[tt].PosX1E=360;
                }
        else{
                Tank1[tt].PosXE=120;
                Tank1[tt].PosX1E=120;
                }
        Tank1[tt].SpeedBB1=9;
        Tank1[tt].PosY1E=30;
        Tank1[tt].PosYE=30;
        Tank1[tt].SpeedT=5;
        tt++;

if (colT<BOT1)
colT++;
if (leftT<0)
leftT--;
}


void __fastcall TForm1::FormShow(TObject *Sender)
{
Form2->ShowModal();        
}

void __fastcall TForm1::Timer4Timer(TObject *Sender)
{
for (int i=0;i<BOT1;i++){
if (Tank1[i].FireBB==false){Tank1[i].SpeedBB1=9;Tank1[i].RandEB();}
     }
}
//---------------------------------------------------------------------------

void TForm1::TestWallBot()
{
for (int t=0;t<BOT1;t++)
{
RECT Rect1=Rect(Tank1[t].PosX1E,Tank1[t].PosY1E,Tank1[t].PosX1E+9,Tank1[t].PosY1E+9);
RECT Rect0=Rect(0,0,0,0);
for (int i=0;i<20;i++)
        {
        for (int j=0;j<20;j++)
                {
                switch (a[i][j])
                        {
                        case 1: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                        {
                                        Tank1[t].PosX1E=800;
                                        Tank1[t].PosY1E=500;
                                        Tank1[t].SpeedBB1=0;
                                        Tank1[t].FireBB=false;
                                        break;
                                        }
                                }
                        case 2: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                        {
                                        a[i][j]=4;
                                        Tank1[t].PosX1E=800;
                                        Tank1[t].PosY1E=500;
                                        Tank1[t].SpeedBB1=0;
                                        Tank1[t].FireBB=false;
                                        break;
                                        }
                                }
                        case 3: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                        {
                                        a[i][j]=0;
                                        Tank1[t].PosX1E=800;
                                        Tank1[t].PosY1E=500;
                                        Tank1[t].SpeedBB1=0;
                                        Tank1[t].FireBB=false;
                                        break;
                                        }
                                 }
                         case 4: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                        {
                                        a[i][j]=5;
                                        Tank1[t].PosX1E=800;
                                        Tank1[t].PosY1E=500;
                                        Tank1[t].SpeedBB1=0;
                                        Tank1[t].FireBB=false;
                                        break;
                                        }
                                }
                          case 5: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                        {
                                        a[i][j]=0;
                                        Tank1[t].PosX1E=800;
                                        Tank1[t].PosY1E=500;
                                        Tank1[t].SpeedBB1=0;
                                        Tank1[t].FireBB=false;
                                        break;
                                        }
                                }
                          case 6: {RECT Rect2=Rect(i*30,j*30,i*30+30,j*30+30);
                                if (IntersectRect(&Rect0,&Rect1,&Rect2))
                                        {
                                        life=-1;
                                        Tank1[t].PosX1E=800;
                                        Tank1[t].PosY1E=500;
                                        Tank1[t].SpeedBB1=0;
                                        Tank1[t].FireBB=false;
                                        break;
                                        }
                                }
                          }
                }
        }
}
}

void TForm1::CollisionTanks()
{       
for (int a=0;a<BOT1;a++){
	for (int b=0;b<BOT1;b++){
		if (a!=b){
			RECT RTank1=Rect(Tank1[a].PosXE,Tank1[a].PosYE,Tank1[a].PosXE+30,Tank1[a].PosYE+30);
			RECT RTank2=Rect(Tank1[b].PosXE,Tank1[b].PosYE,Tank1[b].PosXE+30,Tank1[b].PosYE+30);
			RECT Rect0=Rect(0,0,0,0);
				if (IntersectRect(&Rect0,&RTank1,&RTank2)){
					if ((Tank1[a].PosXE>110&&Tank1[a].PosXE<160&&Tank1[a].PosYE<60)||(Tank1[a].PosXE>350&&Tank1[a].PosXE<400&&Tank1[a].PosYE<60)){}
					else{
						Tank1[a].PosXE=Tank1[a].PosXX[0];
						Tank1[a].PosYE=Tank1[a].PosYX[0];
						Tank1[b].RandE();
						Tank1[a].RandE();break;
						}
					}
				}
	}
}
}

void TForm1::Pause() //wlaczamy pause :)
{
if (Timer1->Enabled){
        pause=true;
        Timer5->Enabled=true;
        Timer1->Enabled=false;
        Timer2->Enabled=false;
        Timer3->Enabled=false;
        Timer4->Enabled=false;
        }
else
        {
        pause=false;
        Timer5->Enabled=false;
        Timer1->Enabled=true;
        Timer2->Enabled=true;
                if (tt==BOT1)Timer3->Enabled=false;
                else
                {
                Timer3->Enabled=true;
                Timer4->Enabled=true;
                }
        }
}

void __fastcall TForm1::Timer5Timer(TObject *Sender)
{

BG->Canvas->Font->Color=clRed;
if (pause)BG->Canvas->TextOutA(Form1->Width-150,500,"Pause"); //rysujemy pause
if (gameover){
        BG->Canvas->Brush->Style = bsClear;
        BG->Canvas->Font->Name="M10_BATTLE CITIES";
        BG->Canvas->Font->Size=55;
        BG->Canvas->TextOutA(0,Form1->Height/3,"You lose"); //co mamy po strzalu w orla
        }
if (win){
        BG->Canvas->Brush->Style = bsClear;
        BG->Canvas->Font->Name="M10_BATTLE CITIES";
        BG->Canvas->Font->Size=55;
        BG->Canvas->Brush->Color=clBlack;
        BG->Canvas->Rectangle(0,0,800,600);
        BG->Canvas->TextOutA(100,20,"You Win");
        BG->Canvas->Font->Name="Century";
        BG->Canvas->TextOutA(100,300,"by \"name?\"");
        BG->Canvas->TextOutA(100,400,"Thx for test");
        }
Form1->Canvas->Draw(0,0,BG);
}
//---------------------------------------------------------------------------
void TForm1::GameOver()
{
if (life<0||lifeA<0){
        gameover=true;
        Timer5->Enabled=true;
        Timer1->Enabled=false;
        Timer2->Enabled=false;
        Timer3->Enabled=false;
        Timer4->Enabled=false;
        }
if (lvl==11){
        win=true;
        Timer5->Enabled=true;
        Timer1->Enabled=false;
        Timer2->Enabled=false;
        Timer3->Enabled=false;
        Timer4->Enabled=false;
        }    
}
void TForm1::NewGame() //generacja nowej gry
{
FILE *f;
lvl=1;
gameover=false;
win=false;
ttime=0;
kill=0;
score=0;
last=BOT1;
life=3;
lifeA=3;
tt=0;
colT=0;
for (int i=0;i<BOT1;i++){
        Tank1[i].FireBB=false;
        Tank1[i].PosXE=600+i*30;
        Tank1[i].PosYE=400;
        Tank1[i].PosX1E=570;
        Tank1[i].PosY1E=400;
        Tank1[i].SpeedBB1=0;
        Tank1[i].SpeedT=0;
        }
if(f=fopen((ExtractFilePath(Application->ExeName) + "map_"+IntToStr(lvl)+".txt").c_str(),"r"))
for (int i=0;i<20;i++)
{
        for(int j=0;j<=20;j++)
        {
        char t=fgetc(f);
        switch (t)
        {
        case '0': a[j][i]=0;break;
        case '1': a[j][i]=1;break;
        case '2': a[j][i]=2;break;
        case '3': a[j][i]=3;break;
        case '4': a[j][i]=4;break;
        case '5': a[j][i]=5;break;
        case '6': a[j][i]=6;break;
        case '7': a[j][i]=7;break;
        case '8': a[j][i]=8;break;
        case '9': a[j][i]=9;break;
        }
        }
}
Timer5->Enabled=false;
Timer1->Enabled=true;
Timer2->Enabled=true;
Timer3->Enabled=true;
Timer4->Enabled=true;
PosX=210;
PosY=540;
}


void TForm1::Nextlvl() //co robimy po przejsciu na nastepny poziom
{
FILE *f;
lvl++;
ttime=0;
BOT1+=5;
tt=0;
colT=0;
last=BOT1;
PosX=210;
PosY=540;
if(TwoPlayers){
        PosXA=330;
        PosYA=540;
        }
Timer5->Enabled=false;
Timer3->Enabled=true;
for (int i=0;i<BOT1;i++){
        Tank1[i].PosXE=600+i*30;
        Tank1[i].PosYE=400;
        Tank1[i].PosY1E=400;
        Tank1[i].PosX1E=570;
        Tank1[i].SpeedBB1=0;
        Tank1[i].SpeedT=0;
        Tank1[i].FireBB=false;
        }
if(f=fopen((ExtractFilePath(Application->ExeName) + "map_"+IntToStr(lvl)+".txt").c_str(),"r"))
for (int i=0;i<20;i++)
{
        for(int j=0;j<=20;j++)
        {
        char t=fgetc(f);
        switch (t)
        {
        case '0': a[j][i]=0;break;
        case '1': a[j][i]=1;break;
        case '2': a[j][i]=2;break;
        case '3': a[j][i]=3;break;
        case '4': a[j][i]=4;break;
        case '5': a[j][i]=5;break;
        case '6': a[j][i]=6;break;
        case '7': a[j][i]=7;break;
        case '8': a[j][i]=8;break;
        case '9': a[j][i]=9;break;
        }
        }

}
}


void TForm1::Bonus() //generujemy bonus
{
int i,j;
i=random(20);
j=random(20);
Bpic=random(2);
switch(Bpic)
{
case 0: bonus->LoadFromFile("picture\\star.bmp");break;
case 1: bonus->LoadFromFile("picture\\heart.bmp");break;
}
if (a[i][j]==0){BonusX=i*30;BonusY=j*30;}  bon=false;
}




