#ifndef Unit1H
#define Unit1H
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TTimer *Timer1;
        TTimer *Timer2;
        TTimer *Timer3;
        TTimer *Timer4;
        TTimer *Timer5;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD&Key, TShiftState Shift); //opracowanie przycisku
        void __fastcall FormKeyUp(TObject *Sender,WORD &Key,
          TShiftState Shift);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall Timer3Timer(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Timer4Timer(TObject *Sender);
        void __fastcall Timer5Timer(TObject *Sender);
private:	// user declaration
public:	//user declaration	
        __fastcall TForm1(TComponent* Owner); //co wywolujemy
        void movetank();
        	void movetankA();
        void draw();
        void Ball();
		void BallA();
        void Comet();
        void testwall();
		void TestWallBot();
        void dmg();
        void CollisionTanks();
        void NewGame();
        void Pause();
        void GameOver();
        void Nextlvl();
        void Bonus();
        void DrawTree();
   
};
extern PACKAGE TForm1 *Form1;
#endif
