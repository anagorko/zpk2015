//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "IniFiles.hpp"
#include "Unit2.h"
#include "Unit1.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
TIniFile *Ini = new TIniFile(ExtractFilePath (Application->ExeName )+"options.ini");
int PosM=1;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormClose(TObject *Sender, TCloseAction &Action)
{
Form1->Timer1->Enabled=true;
Form1->Timer2->Enabled=true;
Form1->Timer3->Enabled=true;
Form1->Left=Form2->Left;
Form1->Top=Form2->Top;
Form1->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Timer1Timer(TObject *Sender)
{
AddFontResourceA("font\\BattleCity.TTF");
Form2->Canvas->Brush->Color=clBlack;
Form2->Canvas->Rectangle(0,0,Form2->Width,Form2->Height);
Form2->Canvas->Font->Name="M10_BATTLE CITIES"; //ccionka
Form2->Canvas->Font->Size=100;  //rozmiar ccionki
Form2->Canvas->Font->Color=clRed;  //kolor ccionki
Form2->Canvas->TextOutA(Form2->Width/6,50,"Tank"); 
Form2->Canvas->Font->Size=20;
Form2->Canvas->Font->Color=clRed;
Form2->Canvas->TextOutA(Form2->Width/3,250,"Play 1 player");
Form2->Canvas->TextOutA(Form2->Width/3,290,"Play 2 player");
Form2->Canvas->TextOutA(Form2->Width/3,330,"Options");
Form2->Canvas->TextOutA(Form2->Width/3,370,"Exit");
if (PosM==1){  //podswietla wybor gracza
Form2->Canvas->Font->Color=clWhite;
Form2->Canvas->TextOutA(Form2->Width/3,250,"Play 1 player");
}
if (PosM==2){
Form2->Canvas->Font->Color=clWhite;
Form2->Canvas->TextOutA(Form2->Width/3,290,"Play 2 player");
}
if (PosM==3){
Form2->Canvas->Font->Color=clWhite;
Form2->Canvas->TextOutA(Form2->Width/3,330,"Options");
}
if (PosM==4){
Form2->Canvas->Font->Color=clWhite;
Form2->Canvas->TextOutA(Form2->Width/3,370,"Exit");
}        
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)  //zasady poruszania sie dol/gora
{
if (Key==VK_UP)
{
PosM--;
if (PosM==0)
PosM=4;
}

if (Key==VK_DOWN)
{
PosM++;
if (PosM==5)
PosM=1;
}
if (Key==VK_RETURN)
{
if (PosM==1)
{Form2->Close();Ini->WriteBool("Settings","Twoplayers",false);}
if (PosM==2)
{Ini->WriteBool("Settings","Twoplayers",true);

Form2->Close();}
if (PosM==3){Form2->Hide();Form3->Show();}
if (PosM==4) {Form2->Close();Form1->Close();}
}
}
//---------------------------------------------------------------------------








