#include <vcl.h>
#pragma hdrstop
#include "Unit2.h"
#include "Unit3.h"
#include "IniFiles.hpp"
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
TIniFile *Ini = new TIniFile(ExtractFilePath (Application->ExeName )+"options.ini");  //wykorzystac domyslne opcje pliku options
int PosM=1;
bool music,sound; 
__fastcall TForm3::TForm3(TComponent* Owner)
        : TForm(Owner)
{
}
//---- przelaczenie formy---
void __fastcall TForm3::Button1Click(TObject *Sender)
{
Form3->Close();
Form2->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormCreate(TObject *Sender)
{
Form3->Left=Form2->Left;
Form3->Top=Form2->Top;
Form3->Width=Form2->Width;
Form3->Height=Form2->Height;
sound=Ini->ReadBool("Settings","Sound","def");
music=Ini->ReadBool("Settings","music","def");
}
//----opisywanie wygladu formy dla 3 okna-------------------
void __fastcall TForm3::Timer1Timer(TObject *Sender)
{
Form3->Canvas->Brush->Color=clBlack;
Form3->Canvas->Rectangle(0,0,Form2->Width,Form2->Height);
Form3->Canvas->Font->Name="M10_BATTLE CITIES";
Form3->Canvas->Font->Size=40;
Form3->Canvas->Font->Color=clRed;
Form3->Canvas->TextOutA(Form3->Width/3,50,"Options");
Form3->Canvas->Font->Size=30;
Form3->Canvas->TextOutA(40,150,"Sound");
Form3->Canvas->TextOutA(Form3->Width-150,150,"On");
Form3->Canvas->TextOutA(40,200,"Music");
Form3->Canvas->TextOutA(Form3->Width-150,200,"On");
Form3->Canvas->TextOutA(Form3->Width-300,Form3->Height-100,"back");
if (PosM==1){  //co podswietlamy bialym kiedy jest aktywne
Form3->Canvas->Font->Color=clWhite;
Form3->Canvas->TextOutA(40,150,"Sound");
}
if (PosM==2){
Form3->Canvas->Font->Color=clWhite;
Form3->Canvas->TextOutA(40,200,"Music");
}
if (PosM==3){
Form3->Canvas->Font->Color=clWhite;
Form3->Canvas->TextOutA(Form3->Width-300,Form3->Height-100,"back");
}
if (sound==false)  //wylaczamy dzwieki, jak ma sie zmienic
{
Form3->Canvas->Font->Color=clGray;
Form3->Canvas->TextOutA(Form3->Width-150,150,"Off");
}
if (music==false)  //wylaczamy muzyke, jak ma sie zmienic
{
Form3->Canvas->Font->Color=clGray;
Form3->Canvas->TextOutA(Form3->Width-150,200,"Off");
}

}

void __fastcall TForm3::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)  //zmiana wydzielonego objektu, strzalkami
{
if (Key==VK_UP)
{
PosM--;
if (PosM==0)
PosM=3;
}
if (Key==VK_DOWN)
{
PosM++;
if (PosM==4)
PosM=1;
}
if (Key==VK_RETURN)
{
        if (PosM==1)
        {
        if (sound)
                {
                sound=false;
                Ini->WriteBool("Settings","sound",false);
                }
        else
                {
                sound=true;
                Ini->WriteBool("Settings","sound",true);
                }
        }
        if (PosM==2)
        {
        if (music)
                {
                music=false;
                Ini->WriteBool("Settings","music",false);
                }
               else
               {
               music=true;
               Ini->WriteBool("Settings","music",true);
               }
        }
        if (PosM==3)
        {
        Form3->Close(); 
        Form2->Show();  //wracamy do ekranu glownego
        }
}
}
