#pragma once
#include "ST_GAME_OBJECT.h"



class Background : public ST_GAME_OBJECT
{
public:
	void Move(const float,const float){};
	void Update(){};

	Background(void);
};

extern Background background;