#include "Geede_player.h"

Geede_player::Geede_player(PlayerID player_id,float x,float y)
{
	onGround = false;
	FreePlane = true;

	texture.loadFromFile(player_id);
	sprite.setTexture(texture);
	sprite.setPosition(x,y);
	SetPosition(x,y);
	Type = OBJ_TYPE_GEEDE;
	SetScore(0);
}


Geede_player::Geede_player(sf::Texture& t,float x,float y)
{
	onGround = false;
	FreePlane = true;

	GravitySpeed = NULL;
	texture = t;
	sprite.setTexture(texture);
	sprite.setPosition(x,y);
	SetPosition(x,y);
	Type = OBJ_TYPE_GEEDE;
	SetScore(0);
	
}


void Geede_player::EnableFreePlane()
{
	FreePlane = true;
	GravitySpeed = NULL;
}


void Geede_player::DisableFreePlane()
{
	FreePlane = false;
}


void Geede_player::Move(const float offset_x,const float offset_y)
{
	if(Player->FreePlane == true)
	{
			sprite.move(offset_x,offset_y);
			return;
	}



	for(int i=0;i<_objects.size();i++)
	{
		float collisionX = sprite.getPosition().x - _objects[i]->GetScreenPosition().x;
		float collisionY = sprite.getPosition().y - _objects[i]->GetScreenPosition().y;
      	
		if(_objects[i]->Type == OBJ_TYPE_BONUS) continue;

		if(abs(collisionX+offset_x)<_objects[i]->sprite.getTextureRect().width )
		{
			if(abs(collisionY) < _objects[i]->sprite.getTextureRect().height) {Speed=0;return;}

			if(abs(collisionY+offset_y)<_objects[i]->sprite.getTextureRect().height && collisionY<0)
				{
					Player->onGround = true;
					Player->Update();
			       return;
				}
			
				if(abs(collisionY+offset_y)<_objects[i]->sprite.getTextureRect().height && collisionY>0)
				{
					Player->GravitySpeed*=-1;
				   
					Player->Update();
			       return;
				}
			
		}


	}
	
		Player->onGround = false;

	sprite.move(offset_x,offset_y);
}


#define FORSE_OF_GRAVITY 0.0005


void Geede_player::Update()
{
	 if(FreePlane == false)
	 {
			 if(onGround == true)
			 GravitySpeed = NULL;

			 else  {
				// cout << GravitySpeed <<endl;
			 GravitySpeed = GravitySpeed + ((FORSE_OF_GRAVITY*geede_time)/100000);
			 Move(NULL,GravitySpeed*geede_time);
			 }
	 }

}



void Geede_player::Jump(const float s)
{
	onGround = false;
	GravitySpeed = -s;
	Update();
}


