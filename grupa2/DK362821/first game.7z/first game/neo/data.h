#pragma once
#include <cmath>

using namespace std;


extern double geede_time;






#define NULL 0

#define _SIDE 42
#define _TOP 5
#define _DOWN 35


   //   �����������
#define DIRECTION short int

#define DIR_LEFT   0
#define DIR_RIGHT  1
#define DIR_UP     2
#define DIR_DOWN   3


   //   ��������

#define PlayerID const std::string




struct ST_Position
{
	double x,y;
};


struct RECT_INT32
{
int x1,y1,x2,y2;
};

struct RECT_INT64
{
long x1,y1,x2,y2;
};

struct RECT_FLOAT32
{
float x1,y1,x2,y2;
};

struct RECT_FLOAT64
{
double x1,y1,x2,y2;
};