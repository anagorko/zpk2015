#include "Textures.h"


void Textures::LoadToMemory()
{
	standart_block.loadFromFile("textures\\block_AS2.png");
	player.loadFromFile("textures\\Player.png");
	PLAYER_DS3.loadFromFile("textures\\PLAYER_DS3.png");
	coin.loadFromFile("textures\\Coin.png");
	list.loadFromFile("textures\\Blocks.png");

}