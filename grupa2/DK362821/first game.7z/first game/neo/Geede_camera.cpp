#include "Geede_camera.h"
extern vector <ST_GAME_OBJECT*> _objects;

Geede_camera::Geede_camera()
{
	Position.x = 0;
	Position.y = 0;
	isFixed = false;
}



void Geede_camera::AddSpeed(const float value)
{
	if(Speed <= MaxSpeed)	 
	Speed = Speed+value;
}


void Geede_camera::LowSpeed(const float value)
{
	Speed = Speed - value;
    if(Speed < 0)
		Speed = 0;
}




void Geede_camera::Stop()
{
   Speed = 0;
}


void Geede_camera::SetSpeed(const float new_speed)
{
	Speed = new_speed;
}


void Geede_camera::SetPosition(const float x,const float y)
{
		Move(Position.x-x,Position.y-y);
}


void Geede_camera::Move(const float offset_x,const float offset_y)
{	
	for(int i=0;i<_objects.size();i++)
	{
		_objects[i]->Move(offset_x,offset_y);
	}

	//Player->Move(offset_x,offset_y);

	Position.x = Position.x-offset_x;
	Position.y = Position.y-offset_y;;

}


void Geede_camera::Move(DIRECTION to)
{
	float offset_x,offset_y;

	bool Test = true;

	switch(to)
	{
	    case DIR_LEFT: 
			offset_x = Speed;
			offset_y = 0;
			break;

		case DIR_RIGHT:
			offset_x = -Speed;
			offset_y = 0;
			break;

		case DIR_UP:
			offset_x = 0;
			offset_y = Speed;
			break;

		case DIR_DOWN:
			offset_x = 0;
			offset_y = -Speed;
			break;

		default:
			Test = false;
			break;
	}

  if(Test == true)	
  {		 
					
		for(int i=0;i<_objects.size();i++)
		{
			_objects[i]->Move(offset_x,offset_y);
		}
   
		Player->sprite.move(offset_x, offset_y);

		Position.x = Position.x - offset_x;
		Position.y = Position.y - offset_y;
  }

}



void Geede_camera::SetFixedObject(ST_GAME_OBJECT* f)
{
	FixedObject = f;
    isFixed = true;
}