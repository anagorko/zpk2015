#pragma once


#define OBJ_TYPE_GEEDE 0
#define OBJ_TYPE_BLOCK 1
#define OBJ_TYPE_ENEMY 2
#define OBJ_TYPE_BONUS 3