#pragma once
#include <SFML\Graphics.hpp>
#include <Windows.h>
#include "game_object.h"
#include "Textures.h"
#include "Geede_camera.h"
#include "Geede_player.h"
#include <vector>
#include "data.h"
#include "geede_object_types.h"
#include "geede_level.h"
#include "Background.h"

extern vector <ST_GAME_OBJECT*> _objects;
extern vector <ST_GAME_OBJECT*>::iterator _objects_iter;
extern Geede_camera Camera;
extern Geede_player* Player;
extern Textures texture_list;
extern RenderWindow *window;


using namespace sf;

class Game
{
private:
Event event;
Clock clock;
Level::geede_level Level;

vector <game_object>::iterator _objects_iter;

void RenderSystemMessages();


public:
void InitWindow();
void Init();
void CreatePlayer(const int,const  int, const float);

void Loop();
  friend class Geede_camera;
  friend class Geede_player;

};
