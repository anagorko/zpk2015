#pragma once
#include <SFML\Graphics.hpp>
#include <string>
#include "data.h"
using namespace sf;



class ST_GAME_OBJECT
{
public:
Texture                texture;
Sprite                 sprite;
ST_Position            Position;
int Type,Name;
RECT_INT32  Rect;
virtual Texture        GetTexture();
virtual Sprite         GetSprite();
virtual ST_Position    GetPosition();
virtual ST_Position    GetScreenPosition();
virtual RECT_INT32*    GetRect(){return &Rect;};

virtual void           SetTexture(Texture*);
virtual void           SetSprite(Sprite*);
virtual void           SetPosition(double x,double y);
virtual void           SetRect(const int,const int,const int,const int);
virtual void           SetPicture(const string);
virtual void           SetPicture(sf::Texture&);
virtual void           Move(const float,const float)=0;
virtual void           Update()=0;
virtual void           Draw(RenderWindow*);
};

