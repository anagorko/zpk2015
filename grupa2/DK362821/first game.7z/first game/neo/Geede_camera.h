#pragma once
#include "data.h"
#include "game_object.h"
#include "Geede_player.h"
#include "ST_GAME_OBJECT.h"
#include <vector>
#include <iostream>
using namespace std;




class Geede_camera
{
private:
		float Speed;
		float MaxSpeed;
		float Boost;
		ST_Position Position;

		ST_GAME_OBJECT* FixedObject;
		bool isFixed;

public:
   
   void AddSpeed(const float value);
   void LowSpeed(const float value);
   void Move(const float offset_x,const float offset_y);
   void Move(DIRECTION to);
   void Stop();
   void SetSpeed(const float new_speed);
   void SetPosition(const float x,const float y);
   void SetFixedObject(ST_GAME_OBJECT*);


   Geede_camera();

   ST_Position GetPosition();
   friend class Game;
   friend class Geede_player;

};

extern  Geede_camera Camera;