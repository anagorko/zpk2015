#include "game_object.h"

game_object::game_object(Texture* t,const float x,const float y)
{
	Type = OBJ_TYPE_BLOCK;
	texture = *t;
	sprite.setTexture(*t);
	sprite.setPosition(x,y);
	Position.x = x;
	Position.y = y;
}
#include <iostream>

game_object::game_object(Texture* t,const float x,const float y,int gid)
{
	int ry = 0;
	int rx = 0;
	
	Type = OBJ_TYPE_BLOCK;
	texture = *t;
	sprite.setTexture(texture);
	SetRect(gid*32-32,0,32,32);
	sprite.setPosition(x,y);

	Position.x = x;
	Position.y = y;
}



void game_object::Move(const float offset_x,const float offset_y)
{
	sprite.move(offset_x,offset_y);
}