#pragma once
#include <SFML\Graphics.hpp>
#include <string>
using namespace sf;


class Textures
{
private:

public:
Texture standart_block;
Texture player;
Texture PLAYER_DS3;
Texture coin;
Sprite obj_list;
Texture	list;

Sprite CLOUD;


void LoadToMemory();
};

extern Textures texture_list;