#include "Coin.h"


Coin::Coin(const float x,const float y)
{
	texture = texture_list.coin;
	sprite.setTexture(texture);
	sprite.setPosition(x,y);
	Type = OBJ_TYPE_BONUS;
}


Coin::~Coin(void)
{
}
