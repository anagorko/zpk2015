#pragma once
#include "pugixml\pugixml.hpp"
#include <iostream>
#include <Windows.h>
#include "game_object.h"
#include "Textures.h"
#include <iostream>
#include "Geede_player.h"
#include <string>
#include "Coin.h"
extern vector <ST_GAME_OBJECT*> _objects;

namespace Level
{
	struct Data
	{
		int BonusCount;
		int BlockCount;
	};

	class MapList
	{
	private:
	    pugi::xml_document  doc;
		pugi::xml_node     root;
		pugi::xml_node     file;

	public:
		
		vector<std::string> maps;
		void LoadFromXML(std::string f)
		{
			if(!doc.load_file(f.c_str()))return;

			root = doc.child("maps");
			file = root.child("File");
 		        while(file)
				{
					maps.push_back((string)"levels\\"+(string)file.attribute("Name").value()+".tmx");
					file = file.next_sibling();
				}
		}

	};


}







namespace Level
{
class geede_level
{
private:

pugi::xml_document doc;
pugi::xml_node root;
pugi::xml_node tileset;
pugi::xml_node image;
pugi::xml_node layer;
pugi::xml_node data;
pugi::xml_node tile;
pugi::xml_node objectgroup;
pugi::xml_node objects;

vector<std::string> map_list;
int current_map;
pugi::xml_attribute att;

int Width,Height;

public:
	MapList MAP_LIST;
	bool FinalMessage;

	void WriteFinalMessage(){ }
	bool isLoad;
	Level::Data info;
	void LoadNextMap();
	bool LoadFromFile(std::string filename);
	void Destroy();
	geede_level::geede_level();
};

}

