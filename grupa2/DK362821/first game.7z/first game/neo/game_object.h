#pragma once
#include "ST_GAME_OBJECT.h"
#include <SFML\Graphics.hpp>
#include "geede_object_types.h"
#include "data.h"

class game_object : public ST_GAME_OBJECT
{
public:
	void  Update(){};
	game_object(Texture* t,const float x,const float y);
	game_object(Texture* t,const float x,const float y,int gid);


		void Move(const float,const float);
};

