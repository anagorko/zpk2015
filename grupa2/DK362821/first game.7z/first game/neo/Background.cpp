#include "Background.h"


Background::Background(void)
{
	texture.loadFromFile("textures\\Background.png");
	sprite.setTexture(texture);
}


Background background;