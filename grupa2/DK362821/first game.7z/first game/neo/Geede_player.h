#pragma once
#include "ST_GAME_OBJECT.h"
#include "object_list.h"
#include "data.h"
#include <iostream>
#include "geede_object_types.h"
#include "Geede_camera.h"
using namespace std;
extern vector <ST_GAME_OBJECT*> _objects;



class Geede_player : public ST_GAME_OBJECT
{
private:

float FP_SPEED;

int Score;
float Speed;
bool  FreePlane;
bool onGround;


float GravitySpeed;

public:
	void SetScore(const int s){Score = s;}
	int  GetScore(){return Score;}
	void AddScore(const int s){Score+=s;}
	void ReduceScore(const int s){Score-=s;if(Score<0)Score=0;};

	void Move(const float,const float);

	void EnableFreePlane();
	void DisableFreePlane();

	float  GetSpeed(){return Speed;}
	void   SetSpeed(float new_speed){Speed = new_speed;}
	void   Update();
	void   Jump(const float);


	Geede_player(PlayerID,float,float);
	Geede_player (sf::Texture&,float,float);


	friend class Game;
	friend class Geede_camera;

};

extern Geede_player* Player;