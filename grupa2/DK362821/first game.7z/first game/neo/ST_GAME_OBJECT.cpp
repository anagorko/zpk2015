#include "ST_GAME_OBJECT.h"


Texture ST_GAME_OBJECT::GetTexture()
{
	return texture;
}

Sprite ST_GAME_OBJECT::GetSprite()
{
	return sprite;
}



ST_Position ST_GAME_OBJECT::GetPosition()
{
	return Position;
}


ST_Position ST_GAME_OBJECT::GetScreenPosition()
{
	ST_Position out;
	
	out.x = sprite.getPosition().x;
	out.y = sprite.getPosition().y;

	return out;
}


void ST_GAME_OBJECT::SetTexture(Texture* T)
{
	texture = *T;
}

void ST_GAME_OBJECT::SetSprite(Sprite* s)
{
	sprite = *s;
}

void ST_GAME_OBJECT::SetPosition(double x,double y)
{
	sprite.setPosition(x,y);
	Position.x = x;
	Position.y = y;
}


void ST_GAME_OBJECT::SetRect(const int x1,const int y1,const int x2,const int y2)
{
	sprite.setTextureRect(IntRect(x1,y1,x2,y2));
	Rect.x1 = sprite.getTextureRect().left;
	Rect.y1 = sprite.getTextureRect().top;
	Rect.x2 = sprite.getTextureRect().width+Rect.x1;
	Rect.y2 = sprite.getTextureRect().height+Rect.y1;
}


void ST_GAME_OBJECT::SetPicture(const string new_picture)
{
	texture.loadFromFile(new_picture);
	sprite.setTexture(texture);
}

void ST_GAME_OBJECT::SetPicture(sf::Texture& t)
{
	texture = t;
	sprite.setTexture(texture);
}



void ST_GAME_OBJECT::Draw(RenderWindow* win)
{
	win->draw(sprite);
}
