#include "geede_level.h"

using namespace Level;

geede_level::geede_level()
{
	current_map = 0;
}


void geede_level::Destroy()
{
	_objects.clear();
	isLoad = false;
}

void geede_level::LoadNextMap()
{	
	Player->EnableFreePlane();
	current_map++;
	if(current_map>2)current_map=0;
	LoadFromFile(MAP_LIST.maps[current_map]);
}


bool geede_level::LoadFromFile(std::string filename)
{
	isLoad = false;
	FinalMessage = false;
	info.BlockCount = 0;
	info.BonusCount = 0;

	if(!doc.load_file(filename.c_str()))return false;
	
	root = doc.child("map");
	tileset = root.child("tileset");
	image = tileset.child("image");
	layer = root.child("layer");
	data = layer.child("data");
	tile = data.child("tile");
	objectgroup = root.child("objectgroup");
	objects = objectgroup.child("object");

	Width  = atoi(layer.attribute("width").value());
	Height = atoi(layer.attribute("height").value());

	if(Width <= 0 || Height <= 0) return false;

	for(int i=0;i<Height;i++)
	{
		for(int j=0;j<Width;j++)
		{
			att = tile.attribute("gid");
			int gid = atoi(att.value());

			if(gid!=0)	_objects.push_back(new game_object(&texture_list.list,j*32,i*32,gid));	
			tile = tile.next_sibling("tile");
		}
	}

	info.BlockCount = Height * Width;


			if(objectgroup.attribute("name").value() == (string)"spawn")   
		     while(objectgroup)	{

			if((string)objectgroup.attribute("name").value() == "spawn")
			while(objects)
			{
				att = objects.attribute("name");	
				
				if((string)att.value() == "player_spawn")
				{
					int x,y;
					x = atoi(objects.attribute("x").value());
					y = atoi(objects.attribute("y").value());	
					Player->SetPosition(x,y);
					break;
				}
				objects = objects.next_sibling("object");
			
			}
				
			
			if((string)objectgroup.attribute("name").value() == "bonus")
			while(objects)
			{
				    info.BonusCount++;
				    int x,y;
					x = atoi(objects.attribute("x").value());
					y = atoi(objects.attribute("y").value());	
					_objects.push_back(new Coin(x,y-16));
				    objects = objects.next_sibling("object");
			}
		
		objectgroup = objectgroup.next_sibling("objectgroup");
		objects =    objectgroup.first_child();
		
		}
	
			 
//		cout << info.BonusCount <<endl;
		isLoad = true;
		return true;
}