#pragma once
#include <SFML\Window.hpp>
#include <SFML\Graphics.hpp>
#pragma comment(lib,"sfml-graphics-s.lib")
#pragma comment(lib,"sfml-system-s.lib")
#pragma comment(lib,"sfml-window-s.lib")

#include "pugixml\pugixml.hpp"
#pragma comment(lib,"pugixml.lib")

#include "Game.h"

vector <ST_GAME_OBJECT*> _objects;
vector <ST_GAME_OBJECT*>::iterator _objects_iter;

Geede_camera Camera;
Geede_player *Player;
Textures texture_list;
RenderWindow *window;

double geede_time;


int WinMain(HINSTANCE,HINSTANCE, PSTR,int)
{
Game *game = new Game;
game->Init();
game->InitWindow();
game->Loop();
}


