#pragma once
#include "ST_GAME_OBJECT.h"
#include <SFML\Graphics.hpp>

class Bonus : public ST_GAME_OBJECT
{
public:
	void  Move(const float x,const float y){sprite.move(x,y);}
};

