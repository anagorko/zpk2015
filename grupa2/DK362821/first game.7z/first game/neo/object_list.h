#pragma once
#include <vector>
#include "game_object.h"
using namespace std;

struct OBJECT_LIST
{
vector <game_object> object;
vector <game_object>::iterator iterator;
};
