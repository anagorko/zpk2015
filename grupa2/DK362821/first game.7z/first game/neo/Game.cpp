#pragma once
#include "Game.h"
void Game::InitWindow()
{
	window = new RenderWindow(VideoMode(800,600),"????????? ??????!!");
}



void Game::Init()
{

	Camera.MaxSpeed = 0.005;
	Camera.Speed =  0;
	texture_list.LoadToMemory();
	Player = new Geede_player(texture_list.player,200,200);
}


void Game::Loop()
{
	Level.MAP_LIST.LoadFromXML("config\\MapList.xml");
	if(!Level.LoadFromFile(Level.MAP_LIST.maps[0]))cout << "������ �������� ����� " <<endl;
	
	Player->SetSpeed(0.0000);
	Player->FP_SPEED = 0.0004; // �������� � ������ ���������� ������

while(window->isOpen())
 {
	 geede_time =  clock.getElapsedTime().asMicroseconds()/2;
	 clock.restart();
	 Camera.SetSpeed(0.0005*geede_time);

	 if(Keyboard::isKeyPressed(Keyboard::A))
	 {
		 Camera.Move(DIR_LEFT);
	 }

	 if(Keyboard::isKeyPressed(Keyboard::D))
	 {
		 Camera.Move(DIR_RIGHT);
	 }


	 if(Keyboard::isKeyPressed(Keyboard::W))
	 {
		 Camera.Move(DIR_UP);
	 }

	 if(Keyboard::isKeyPressed(Keyboard::S))
	 {
		 Camera.Move(DIR_DOWN);
	 }


	 if(Keyboard::isKeyPressed(Keyboard::Up) && Player->FreePlane)
	 {
		 Player->Move(0,-Player->FP_SPEED*geede_time);
	 }

	 if(Keyboard::isKeyPressed(Keyboard::Down))
	 {
		if(Player->FreePlane)Player->Move(0,Player->FP_SPEED*geede_time);
	 }

	 if(Keyboard::isKeyPressed(Keyboard::Right))
	 {
		 if(!Player->FreePlane)
		 {
		 Player->Speed+=0.000000002*geede_time;
		 Player->Move(Player->GetSpeed()*geede_time,0);
		 }
		 
		 else Player->Move(Player->FP_SPEED*geede_time,0);
	 }

	 if(Keyboard::isKeyPressed(Keyboard::Left))
	 {
		 if(!Player->FreePlane)
		 {
		 Player->Speed-=0.000000002*geede_time;
		 Player->Move(Player->GetSpeed()*geede_time,0);
		 }
		 
		 else Player->Move(-Player->FP_SPEED*geede_time,0);
	 }

	 if(!Keyboard::isKeyPressed(Keyboard::Left) && !
		 Keyboard::isKeyPressed(Keyboard::Right)&& !
		 Player->FreePlane
		 )
	 {
		  if(Player->Speed<0)Player->Speed+=0.000000001*geede_time;
		  if(Player->Speed>0)Player->Speed-=0.000000001*geede_time;
		  
		  if(Player->Speed!=0)Player->Move(Player->Speed*geede_time,0);
	 }

	 if(Level.isLoad == true)
	 {
		 // ���� ������� ��� ������
		 if(Player->GetScore() == Level.info.BonusCount && Level.FinalMessage == false)
		 {
			 Level.WriteFinalMessage();
		 }

	 }


	Player->Update();
	
	RenderSystemMessages();
	
  _objects.erase(remove_if(_objects.begin(),_objects.end(),[](ST_GAME_OBJECT* p)->bool
  {
	      int collision_x,collision_y;
		  
		  if(p->Type == OBJ_TYPE_BONUS)
		  {
		  collision_x = abs(Player->GetScreenPosition().x-p->GetScreenPosition().x);
		  collision_y = abs(Player->GetScreenPosition().y-p->GetScreenPosition().y);

		  if(collision_x<32 && collision_y<32)
			  {
				  Player->AddScore(1);
				  return true;
			  }
		  return false;
		 
		  }
  }),_objects.end());


	window->clear();
	
	window->draw(background.sprite);


  for(int i=0;i<_objects.size();i++)
  {
	  if(_objects[i]->GetScreenPosition().x < -_objects[i]->GetRect()->x2 || _objects[i]->GetScreenPosition().x > 800) 
	     continue;
	  else
		  window->draw(_objects[i]->sprite);
  
  }


  Player->Draw(window);

  window->display();

 }

}



void Game::RenderSystemMessages()
{
		    while(window->pollEvent(event))
            {
			   
				if(event.type == Event::Closed)
				  window->close(); 

				if(event.key.code == Keyboard::LShift)
				{
					 Player->DisableFreePlane();
				}
			
				
				if(event.type == sf::Event::KeyPressed)
				{
					if(event.key.code == sf::Keyboard::C) {
					Level.Destroy();
					Level.LoadNextMap();Sleep(10);}
				}


				if(event.key.code == Keyboard::LControl)
				{
					Player->EnableFreePlane();
				}

				if(event.key.code == Keyboard::Space)
				{
					if(Player->onGround == true)Player->Jump(0.0013);
				}

			}

}