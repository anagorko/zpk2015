#pragma once
#include "Bonus.h"
#include "Textures.h"
#include "geede_object_types.h"
class Coin : public Bonus
{
public:
	void  Update(){};
	Coin(const float x,const float y);
	~Coin(void);
};

