#ifndef PLAY_H
#define PLAY_H

#include "GameState.h"
#include "Menu.h"
#include "Pause.h"
#include "Score.h"

#include <string>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <queue>
#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>

class Play : public GameState
{
    public:
        Play(Game* game, double s);
        ~Play();


        virtual void draw();
        virtual void input(ALLEGRO_KEYBOARD_STATE* keyboard);
        virtual void update();


    private:
        void dead();
        void newPoint();
        void randomBonus();
        void nLevel(bool next);
        void checkHit(int x, int y);
        bool ate;
        double time;
        double speed;
        int rand1, rand2;
        int lives;
        int level;
        int score;
        int snakeLength;
        int **board;
        int moveDirection;
        std::queue <int> snakeX;
        std::queue <int> snakeY;

        ALLEGRO_FONT *font_ttf_30;
        ALLEGRO_FONT *font_ttf_20;

        ALLEGRO_BITMAP *snake; //kod 1
        ALLEGRO_BITMAP *point; // kod 2
        ALLEGRO_BITMAP *specialPoint; //kod 3
        ALLEGRO_BITMAP *unknownBonus; //kod 4
        ALLEGRO_BITMAP *nextLevel; // kod 5
        ALLEGRO_BITMAP *heart; //kod 6
        ALLEGRO_BITMAP *obstacle; //kod 7
        ALLEGRO_BITMAP *plus3; // kod 8
        ALLEGRO_BITMAP *minus3; //kod9
        ALLEGRO_BITMAP *plus30; //kod10
        ALLEGRO_BITMAP *minus30; //kod 11
        ALLEGRO_BITMAP *plusSpeed; //kod 12
        ALLEGRO_BITMAP *minusSpeed; //kod13
};

#endif // PLAY_H
