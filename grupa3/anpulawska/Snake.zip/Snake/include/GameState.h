#ifndef GAMESTATE_H
#define GAMESTATE_H

#include "Game.h"
#include <allegro5/allegro.h>
//klasa pozwalaj�ca obs�ugiwac wszystki stany gry
class GameState
{
    public:
        Game* game;//wska�nik na game, pozwoli odnosi� si� bezpo�rednio do funkcji klasy game
        virtual void draw() = 0;
        virtual void update() = 0;
        virtual void input(ALLEGRO_KEYBOARD_STATE* keyboard) = 0;

    protected:

    private:
};

#endif // GAMESTATE_H
