#ifndef RULES_H
#define RULES_H

#include "GameState.h"
#include "Menu.h"

#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>

class Rules : public GameState
{
    public:
        Rules(Game* game);
        virtual ~Rules();

        virtual void draw();
        virtual void input(ALLEGRO_KEYBOARD_STATE* keyboard);
        virtual void update();

    private:
        ALLEGRO_FONT *font_ttf_50;
        ALLEGRO_FONT *font_ttf_30; //czcionka
        ALLEGRO_FONT *font_ttf_20;

        ALLEGRO_BITMAP *snake;
        ALLEGRO_BITMAP *point;
        ALLEGRO_BITMAP *specialPoint;
        ALLEGRO_BITMAP *unknownBonus;
        ALLEGRO_BITMAP *nextLevel;
        ALLEGRO_BITMAP *heart;
        ALLEGRO_BITMAP *plus3;
        ALLEGRO_BITMAP *minus3;
        ALLEGRO_BITMAP *plus30;
        ALLEGRO_BITMAP *minus30;
        ALLEGRO_BITMAP *plusSpeed;
        ALLEGRO_BITMAP *minusSpeed;
};

#endif // RULES_H
