#ifndef GAME_H
#define GAME_H

#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <stack>

class GameState;

class Game
{
    public:
        Game();
        virtual ~Game();

        void gameLoop(); //główna pętla gry

        ALLEGRO_DISPLAY *window;
        ALLEGRO_KEYBOARD_STATE keyboard;


        std::stack<GameState*> states; //stos reprezentuj¹cy stany gry takie jak Menu, Rules czy Gra
        void pushState(GameState* state); //poniższe funkcje obsługują stos, zgodnie z nazwami
        void popState();
        void changeState(GameState* state);
        GameState* peekState();

        const int width = 800; //domysle wymiary okna
        const int height = 600;
        double speed;
        double time;
        void endGame();
    private:
        bool exit;
};

#endif // GAME_H
