#ifndef PAUSE_H
#define PAUSE_H

#include "GameState.h"

#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>


class Pause : public GameState
{
    public:
        Pause(Game* game);
        virtual ~Pause();

        virtual void draw();
        virtual void input(ALLEGRO_KEYBOARD_STATE* keyboard);
        virtual void update();

    private:
        ALLEGRO_FONT *font_ttf_30;
        ALLEGRO_FONT *font_ttf_50;
};

#endif // PAUSE_H
