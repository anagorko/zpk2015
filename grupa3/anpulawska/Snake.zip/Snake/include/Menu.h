#ifndef MENU_H
#define MENU_H

#include "GameState.h"
#include "Rules.h"
#include "Play.h"

#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>

class Menu : public GameState
{
    public:
        Menu(Game* game);
        virtual ~Menu();

        virtual void input(ALLEGRO_KEYBOARD_STATE* keyboard);
        virtual void update();
        virtual void draw();

    private:
        ALLEGRO_FONT *font_ttf_30; //czcionka
        ALLEGRO_FONT *font_ttf_20;
        ALLEGRO_BITMAP *bitmap;

};

#endif // MENU_H
