#ifndef SCORE_H
#define SCORE_H

#include "GameState.h"
#include "Menu.h"
#include "Play.h"


#include <string>
#include <sstream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>

class Score : public GameState
{
    public:
        Score(Game* game, int s);
        virtual ~Score();

        virtual void draw();
        virtual void input(ALLEGRO_KEYBOARD_STATE* keyboard);
        virtual void update();


    private:
        int score;
        ALLEGRO_FONT *font_ttf_50;
        ALLEGRO_FONT *font_ttf_30; //czcionka
        ALLEGRO_FONT *font_ttf_20;
};

#endif // SCORE_H
