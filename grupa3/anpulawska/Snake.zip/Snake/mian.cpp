#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>

#include "Game.h"
int main()
{
    Game gamfe;

    return 0;
}



