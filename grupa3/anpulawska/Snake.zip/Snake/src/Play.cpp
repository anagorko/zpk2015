#include "Play.h"

Play::Play(Game* game, double s)
{
    this->game = game;

    speed = 0.5;

    font_ttf_30 = al_load_ttf_font("courbd.ttf",30,0);
    font_ttf_20 = al_load_ttf_font("courbd.ttf",20,0);

    board = new int*[28];
    for (int i = 0; i < 28; i++)
	{
		board[i] = new int[28];
	}
	board[14][14] = 1;
	board[13][14] = 1;
	board[12][14] = 1;
	board[11][14] = 1;

	snakeX.push(11);
	snakeX.push(12);
	snakeX.push(13);
	snakeX.push(14);
	snakeY.push(14);
	snakeY.push(14);
	snakeY.push(14);
	snakeY.push(14);

    obstacle = al_load_bitmap("obstacle.png");
    snake = al_load_bitmap("snake.png");
    heart = al_load_bitmap("heart.png");
    point = al_load_bitmap("point.png");
    specialPoint = al_load_bitmap("specialPoint.png");
    unknownBonus = al_load_bitmap("unknownBonus.png");
    nextLevel = al_load_bitmap("nextLevel.png");
    plus3 = al_load_bitmap("plus3.png");
    minus3 = al_load_bitmap("minus3.png");
    plus30 = al_load_bitmap("plus30.png");
    minus30 = al_load_bitmap("minus30.png");
    plusSpeed = al_load_bitmap("plusSpeed.png");
    minusSpeed = al_load_bitmap("minusSpeed.png");

    moveDirection = 0;
    snakeLength = 4;
    score = 0;
    level = 1;
    lives = 0;
    ate = false;


    newPoint();


}
Play::~Play()
{
    delete board;
}
void Play::draw()
{
    al_draw_bitmap(heart, 50, 53, 0);
    std::stringstream sstream;
    sstream<<"x "<<(lives);
    al_draw_textf(font_ttf_30, al_map_rgb(0,0,0), 80, 50, 0, sstream.str().c_str());

    sstream.str(std::string());
    sstream<<"SCORES: "<<(score);
    al_draw_textf(font_ttf_20, al_map_rgb(0,0,0), 50, 100, 0, sstream.str().c_str());

    sstream.str(std::string());
    sstream<<"LEVEL: "<<(level);
    al_draw_textf(font_ttf_20, al_map_rgb(0,0,0), 50, 150, 0, sstream.str().c_str());

    al_draw_textf(font_ttf_30, al_map_rgb(0,0,0), 50, 400, 0, "Pause");
    al_draw_textf(font_ttf_20, al_map_rgb(0,0,0), 50, 430, 0, "Press P");
    al_draw_textf(font_ttf_30, al_map_rgb(0,0,0), 50, 480, 0, "Exit");
    al_draw_textf(font_ttf_20, al_map_rgb(0,0,0), 50, 510, 0, "Press E");

    al_draw_filled_rectangle(200,0,800,20,al_map_rgb(0,0,0));
    al_draw_filled_rectangle(200,0,220,600,al_map_rgb(0,0,0));
    al_draw_filled_rectangle(200,580,800,600,al_map_rgb(0,0,0));
    al_draw_filled_rectangle(780,0,800,600,al_map_rgb(0,0,0));

    for (int x = 0; x<28; x++)
        for (int y = 0; y<28; y++)
            switch (board[x][y])
            {
            case 1:
                al_draw_bitmap(snake, 220 + x*20, 20+y*20, 0);
                break;
            case 2:
                al_draw_bitmap(point, 220 + x*20, 20+y*20, 0);
                break;
            case 3:
                al_draw_bitmap(specialPoint, 220 + x*20, 20+y*20, 0);
                break;
            case 4:
                al_draw_bitmap(unknownBonus, 220 + x*20, 20+y*20, 0);
                break;
            case 5:
                al_draw_bitmap(nextLevel, 220 + x*20, 20+y*20, 0);
                break;
            case 6:
                al_draw_bitmap(heart, 220 + x*20, 20+y*20, 0);
                break;
            case 7:
                al_draw_bitmap(obstacle, 220 + x*20, 20+y*20, 0);
                break;
            case 8:
                al_draw_bitmap(plus3, 220 + x*20, 20+y*20, 0);
                break;
            case 9:
                al_draw_bitmap(minus3, 220 + x*20, 20+y*20, 0);
                break;
            case 10:
                al_draw_bitmap(plus30, 220 + x*20, 20+y*20, 0);
                break;
            case 11:
                al_draw_bitmap(minus30, 220 + x*20, 20+y*20, 0);
                break;
            case 12:
                al_draw_bitmap(plusSpeed, 220 + x*20, 20+y*20, 0);
                break;
            case 13:
                al_draw_bitmap(minusSpeed, 220 + x*20, 20+y*20, 0);
                break;

            }

}

void Play::input(ALLEGRO_KEYBOARD_STATE* keyboard)
{
    if(al_key_down(keyboard, ALLEGRO_KEY_W) || al_key_down(keyboard, ALLEGRO_KEY_UP))
        if(moveDirection != 1)
            moveDirection = 0;
    if(al_key_down(keyboard, ALLEGRO_KEY_S) || al_key_down(keyboard, ALLEGRO_KEY_DOWN))
        if(moveDirection != 0)
            moveDirection = 1;
    if(al_key_down(keyboard, ALLEGRO_KEY_A) || al_key_down(keyboard, ALLEGRO_KEY_LEFT))
        if(moveDirection != 3)
            moveDirection = 2;
    if(al_key_down(keyboard, ALLEGRO_KEY_D) || al_key_down(keyboard, ALLEGRO_KEY_RIGHT))
        if(moveDirection != 2)
            moveDirection = 3;
    if(al_key_down(keyboard, ALLEGRO_KEY_P))
        game->pushState(new Pause(game));
    if(al_key_down(keyboard, ALLEGRO_KEY_E))
       game->changeState(new Menu(game));
}
void Play::nLevel(bool next)
{
    if(next)
        level++;


    for (int x = 0; x<28; x++)
        for (int y = 0; y<28; y++)
            board[x][y] = 0;

    snakeLength = 4;


    while(!snakeX.empty())
        snakeX.pop();
    while(!snakeY.empty())
        snakeY.pop();

    snakeX.push(11);
	snakeX.push(12);
	snakeX.push(13);
	snakeX.push(14);
	snakeY.push(14);
	snakeY.push(14);
	snakeY.push(14);
	snakeY.push(14);

	board[14][14] = 1;
	board[13][14] = 1;
	board[12][14] = 1;
	board[11][14] = 1;

	newPoint();

}
void Play::dead()
{

    if (lives == 0)
    {
        game->changeState(new Score(game, score));
    }

    else
    {

        lives--;
        nLevel(false);
    }

}
void Play::randomBonus()
{
    rand1 = rand()%100;
    if(rand1 < 25)
        score +=3;
    else if(rand1 < 55)
        score -=3;
    else if(rand1 < 60)
        score +=30;
    else if(rand1 < 75)
        score -=3;
    else if(rand1 < 90)
        game->speed /= 2;
    else
        game->speed *= 2;

}
void Play::newPoint()
{
    snakeLength++;
    if(snakeLength > 30)
    {
        rand1= rand() %28;
        rand2 = rand() %28;
        while (board[rand1][rand2]!=0)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
        }
        board[rand1][rand2] = 5;
    }
    rand1= rand() %28;
    rand2 = rand() %28;
    while (board[rand1][rand2]!=0)
    {
        rand1= rand() %28;
        rand2 = rand() %28;
    }
    board[rand1][rand2] = rand2%2 + 2;
    if (rand()%8 == 1)
    {
        rand1 = rand()%100;
        if(rand1<20)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 4;
        }
        else if(rand1<21)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 5;
        }
        else if(rand1<54)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 8;
        }
        else if(rand1<85)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 9;
        }
        else if(rand1<87)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 10;
        }
        else if(rand1<89)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 11;
        }
        else if(rand1<95)
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 12;
        }
        else
        {
            rand1= rand() %28;
            rand2 = rand() %28;
            while (board[rand1][rand2]!=0)
            {
                rand1= rand() %28;
                rand2 = rand() %28;
            }
            board[rand1][rand2] = 13;
        }
    }

}
void Play::update()
{
    switch(moveDirection)
    {
    case 0:
        if(snakeY.back() == 0)
            dead();

        checkHit(snakeX.back(),snakeY.back()-1);


        snakeX.push(snakeX.back());
        snakeY.push(snakeY.back()-1);

        board[snakeX.back()][snakeY.back()] = 1;
        break;
    case 1:
        if(snakeY.back() == 27)
            dead();

        checkHit(snakeX.back(),snakeY.back()+1);

        snakeX.push(snakeX.back());
        snakeY.push(snakeY.back()+1);

        board[snakeX.back()][snakeY.back()] = 1;
        break;
    case 2:
        if(snakeX.back() == 0)
            dead();

        checkHit(snakeX.back()-1,snakeY.back());

        snakeX.push(snakeX.back()-1);
        snakeY.push(snakeY.back());

        board[snakeX.back()][snakeY.back()] = 1;
        break;
    case 3:

        if(snakeX.back() == 27)
            dead();


        checkHit(snakeX.back()+1,snakeY.back());
        snakeX.push(snakeX.back()+1);
        snakeY.push(snakeY.back());
        board[snakeX.back()][snakeY.back()] = 1;
        break;
    }
    if (!ate)
    {
        board[snakeX.front()][snakeY.front()] = 0;
        snakeX.pop();
        snakeY.pop();
    } else
    {
       ate = false;
    }



}
void Play::checkHit(int x, int y)
{
    switch (board[x][y])
        {
        case 1:
            dead();
            break;
        case 2:
            ate = true;
            score++;
            newPoint();
            break;
        case 3:
            ate = true;
            score +=2;
            newPoint();
            break;
        case 4:
            randomBonus();
            break;
        case 5:
            nLevel(true);
            break;
        case 6:
            lives++;
            break;
        case 7:
            dead();
            break;
        case 8:
            score += 3;
            break;
        case 9:
            score -= 3;
            break;
        case 10:
            score += 30;
            break;
        case 11:
            score -= 30;
            break;
        case 12:
            game->speed = game->speed /2;
            break;
        case 13:
            game->speed = game->speed *2;
            break;
        }
}
