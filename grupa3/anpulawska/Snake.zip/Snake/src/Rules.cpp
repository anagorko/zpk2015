#include "Rules.h"

Rules::Rules(Game* game)
{
    this->game = game;

    font_ttf_50 = al_load_ttf_font("courbd.ttf",50,0);
    font_ttf_30 = al_load_ttf_font("courbd.ttf",30,0);
    font_ttf_20 = al_load_ttf_font("courbd.ttf",20,0);
    snake = al_load_bitmap("snake.png");
    heart = al_load_bitmap("heart.png");
    point = al_load_bitmap("point.png");
    specialPoint = al_load_bitmap("specialPoint.png");
    unknownBonus = al_load_bitmap("unknownBonus.png");
    nextLevel = al_load_bitmap("nextLevel.png");
    plus3 = al_load_bitmap("plus3.png");
    minus3 = al_load_bitmap("minus3.png");
    plus30 = al_load_bitmap("plus30.png");
    minus30 = al_load_bitmap("minus30.png");
    plusSpeed = al_load_bitmap("plusSpeed.png");
    minusSpeed = al_load_bitmap("minusSpeed.png");

}

Rules::~Rules()
{
    //dtor
}

void Rules::draw()
{
    al_draw_text (font_ttf_50,al_map_rgb(0,0,0), game->width/2, 50, ALLEGRO_ALIGN_CENTRE,"Rules");


    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 150, 150, 0,"- snake");
    al_draw_bitmap(snake, 100, 152, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 150, 200, 0,"- averange points");
    al_draw_bitmap(point, 100, 202, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 150, 250, 0,"- special points");
    al_draw_bitmap(specialPoint, 100, 252, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 150, 300, 0,"- unknown bonus");
    al_draw_bitmap(unknownBonus, 100, 302, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 150, 350, 0,"- extra life");
    al_draw_bitmap(heart, 100, 352, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 150, 400, 0,"- next level");
    al_draw_bitmap(nextLevel, 100, 402, 0);

    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 550, 150, 0,"- plus score");
    al_draw_bitmap(plus3, 500, 152, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 550, 200, 0,"- minus score");
    al_draw_bitmap(minus3, 500, 202, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 550, 250, 0,"- plus score");
    al_draw_bitmap(plus30, 500, 252, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 550, 300, 0,"- minus score");
    al_draw_bitmap(minus30, 500, 302, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 550, 350, 0,"- plus speed");
    al_draw_bitmap(plusSpeed, 500, 352, 0);
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 550, 400, 0,"- minus speed");
    al_draw_bitmap(minusSpeed, 500, 402, 0);


    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, 490, ALLEGRO_ALIGN_CENTRE,"Close");
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), game->width/2, 520, ALLEGRO_ALIGN_CENTRE,"Press C");

}
void Rules::input(ALLEGRO_KEYBOARD_STATE* keyboard)
{
    if(al_key_down(keyboard, ALLEGRO_KEY_C)) game->changeState(new Menu(game));

}
void Rules::update()
{

}
