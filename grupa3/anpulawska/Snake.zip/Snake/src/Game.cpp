#include "Game.h"
#include "GameState.h"
#include "Menu.h"

Game::Game()
{
    al_init(); //konfiguracja allegro i tworzenie okna
    al_install_keyboard();
    al_init_image_addon();
    al_init_font_addon();
    al_init_ttf_addon();
    al_init_primitives_addon();


    window = al_create_display( width, height);
    al_set_window_title( window,"Snake");
    pushState(new Menu(this));
    speed = 0.1;
    time = al_get_time();
    exit = false;
    gameLoop();
}

Game::~Game()
{
    al_destroy_display(window);
}

void Game::gameLoop()
{
    while(true)
    {
        al_get_keyboard_state(&keyboard);
        peekState()->input(&keyboard);
        if((time+speed)<=al_get_time())
        {
            time = al_get_time();
            peekState()->update();

        }
        al_clear_to_color(al_map_rgb(192,192,192));
        peekState()->draw();
        al_flip_display();
        if(exit)
        {
            popState();
            break;
        }



    };
}
void Game::pushState(GameState* state)
{
    this->states.push(state);

    return;
}

void Game::popState()
{
    delete this->states.top();
    this->states.pop();

    return;
}

void Game::changeState(GameState* state)
{
    if(!this->states.empty())
        popState();
    pushState(state);

    return;
}

GameState* Game::peekState()
{
    if(this->states.empty()) return nullptr;
    return this->states.top();
}
void Game::endGame()
{
    exit=true;
}
