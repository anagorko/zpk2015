#include "Score.h"

Score::Score(Game* game, int s)
{

    this->game = game;
    score = s;


    font_ttf_50 = al_load_ttf_font("courbd.ttf",50,0);
    font_ttf_30 = al_load_ttf_font("courbd.ttf",30,0);
    font_ttf_20 = al_load_ttf_font("courbd.ttf",20,0);

}

Score::~Score()
{
    //dtor
}
void Score::draw()
{
    std::stringstream sstream;
    sstream<<"Your score: "<<score;
    al_draw_text (font_ttf_50,al_map_rgb(0,0,0), game->width/2, 200, ALLEGRO_ALIGN_CENTRE,"Game Over");
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, 250, ALLEGRO_ALIGN_CENTRE,sstream.str().c_str());
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, 350, ALLEGRO_ALIGN_CENTRE,"Play Again?");
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), game->width/2, 380, ALLEGRO_ALIGN_CENTRE,"Press P");
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, 520, ALLEGRO_ALIGN_CENTRE,"Back to menu");
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), game->width/2, 550, ALLEGRO_ALIGN_CENTRE,"Press C");

}
void Score::update()
{

}
void Score::input(ALLEGRO_KEYBOARD_STATE* keyboard)
{
    if(al_key_down(keyboard, ALLEGRO_KEY_C)) game->changeState(new Menu(game));
    if(al_key_down(keyboard, ALLEGRO_KEY_P)) game->changeState(new Play(game, game->speed));

}
