#include "Pause.h"

Pause::Pause(Game* game)
{
    this->game = game;

    font_ttf_30 = al_load_ttf_font("courbd.ttf",30,0);
    font_ttf_50 = al_load_ttf_font("courbd.ttf",50,0);
}

Pause::~Pause()
{
    //dtor
}
void Pause::draw()
{
    al_draw_text (font_ttf_50,al_map_rgb(0,0,0), game->width/2, 280, ALLEGRO_ALIGN_CENTRE,"Pause");
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, 340, ALLEGRO_ALIGN_CENTRE,"Press X");

}
void Pause::input(ALLEGRO_KEYBOARD_STATE* keyboard)
{
    if(al_key_down(keyboard, ALLEGRO_KEY_X))
        game->popState();
}
void Pause::update()
{

}
