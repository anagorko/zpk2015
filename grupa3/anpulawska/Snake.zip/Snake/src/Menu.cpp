#include "Menu.h"

Menu::Menu(Game* game)
{
    this->game = game;

    font_ttf_30 = al_load_ttf_font("courbd.ttf",30,0);
    font_ttf_20 = al_load_ttf_font("courbd.ttf",20,0);
    bitmap = al_load_bitmap("logoSnake.png");
}

Menu::~Menu()
{
}
void Menu::draw()
{
    al_draw_bitmap(bitmap, (game->width - al_get_bitmap_width(bitmap))/2, 30, 0);
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, game->height/2, ALLEGRO_ALIGN_CENTRE,"Choose level:");

    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), 200, 390, ALLEGRO_ALIGN_CENTRE,"Slow");
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), 400, 390, ALLEGRO_ALIGN_CENTRE,"Medium");
    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), 600, 390, ALLEGRO_ALIGN_CENTRE,"Fast");

    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 200, 420, ALLEGRO_ALIGN_CENTRE,"Press S");
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 400, 420, ALLEGRO_ALIGN_CENTRE,"Press M");
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), 600, 420, ALLEGRO_ALIGN_CENTRE,"Press F");

    al_draw_text (font_ttf_30,al_map_rgb(0,0,0), game->width/2, 490, ALLEGRO_ALIGN_CENTRE,"Rules");
    al_draw_text (font_ttf_20,al_map_rgb(0,0,0), game->width/2, 520, ALLEGRO_ALIGN_CENTRE,"Press R");

}
void Menu::input(ALLEGRO_KEYBOARD_STATE* keyboard)
{
    if(al_key_down(keyboard, ALLEGRO_KEY_ESCAPE)) game->endGame();
    if(al_key_down(keyboard, ALLEGRO_KEY_R)) game->changeState(new Rules(game));
    if(al_key_down(keyboard, ALLEGRO_KEY_S))
    {
        game->changeState(new Play(game, 0.3));
        game->speed = 1;
    }
    if(al_key_down(keyboard, ALLEGRO_KEY_M))
    {
        game->changeState(new Play(game, 0.1));
        game->speed = 0.3;
    }
    if(al_key_down(keyboard, ALLEGRO_KEY_F))
    {
        game->changeState(new Play(game, 0.05));
        game->speed = 0.1;
    }


}
void Menu::update()
{

}
