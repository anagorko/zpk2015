#include "Cubic.h"

Cubic::Cubic()
{
   double c = 1;

   // apex
    Point p = Point(0.0, 0.0, 0.0);
    points.push_back(p);
    p = Point( 0.0,   0.0,  1.0);
    points.push_back(p);
    p  = Point( 0.0,  1.0,   0.0);
    points.push_back(p);
    p  = Point( 1.0,  0.0,  0.0);
    points.push_back(p);
    p  = Point( 1.0 ,  1.0,   0.0);
    points.push_back(p);
    p  = Point(  1.0,  0.0,  1.0);
    points.push_back(p);
    p  = Point( 0.0,  1.0,   1.0);
    points.push_back(p);
    p  = Point( 1.0,  1.0,  1.0);
    points.push_back(p);



    // edges represent as index to apex list
     Edge e = Edge(0, 1);
     edges.push_back(e);
     e = Edge(0, 2);
     edges.push_back(e);
     e = Edge(0, 3 );
     edges.push_back(e);
     e = Edge(1, 5);
     edges.push_back(e);

     e = Edge(1, 6);
     edges.push_back(e);
     e = Edge(2, 4);
     edges.push_back(e);
     e = Edge(2, 6);
     edges.push_back(e);
     e = Edge(3, 4);
     edges.push_back(e);

     e = Edge(3, 5);
     edges.push_back(e);
     e = Edge(4, 7);
     edges.push_back(e);
     e = Edge(5, 7);
     edges.push_back(e);
     e = Edge(6, 7);
     edges.push_back(e);




}

Cubic::~Cubic()
{
    //dtor
}


void Cubic:: draw()
{
  for( int i = 0; i<edges.size() ; i ++ )
  {
        Point p1 = points[edges[i].getA()].projection(4);
        Point p2 = points[edges[i].getB()].projection(4);
        al_draw_line(400 + p1.getX()*100, 300 + p1.getY()* 100, 400 + p2.getX() * 100, 300 + p2.getY() * 100, al_map_rgb(255,255,255),1);
  };
}

