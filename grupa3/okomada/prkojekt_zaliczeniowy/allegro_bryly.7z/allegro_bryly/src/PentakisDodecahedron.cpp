#include "PentakisDodecahedron.h"

PentakisDodecahedron::PentakisDodecahedron()
{

    double c0 = 0.927050983124842272306880251548;
    double c1 = 1.33058699733550141141687582919;
    double c2 = 2.15293498667750705708437914596;
    double c3 = 2.427050983124842272306880251548;

   // wierzcholki
    Point   p = Point(0.0, c0, c3);
            points.push_back(p);
            p = Point( 0.0,   c0,  -c3);
            points.push_back(p);
            p  = Point( 0.0,  -c0,   c3);
            points.push_back(p);
            p  = Point( 0.0,  -c0,  -c3);
            points.push_back(p);
            p  = Point(  c3,  0.0,   c0);
            points.push_back(p);
            p  = Point(  c3,  0.0,  -c0);
            points.push_back(p);
            p  = Point( -c3,  0.0,   c0);
            points.push_back(p);
            p  = Point( -c3,  0.0,  -c0);
            points.push_back(p);
            p  = Point(  c0,   c3,  0.0);
            points.push_back(p);
            p  = Point(  c0,  -c3,  0.0);
            points.push_back(p);
            p = Point( -c0,   c3,  0.0);
            points.push_back(p);
            p = Point( -c0,  -c3,  0.0);
            points.push_back(p);
            p = Point(  c1,  0.0,   c2);
            points.push_back(p);
            p = Point(  c1,  0.0,  -c2);
            points.push_back(p);
            p = Point( -c1,  0.0,   c2);
            points.push_back(p);
            p = Point( -c1,  0.0,  -c2);
            points.push_back(p);
            p = Point(  c2,   c1,  0.0);
            points.push_back(p);
            p = Point(  c2,  -c1,  0.0);
            points.push_back(p);
            p = Point( -c2,   c1,  0.0);
            points.push_back(p);
            p = Point( -c2,  -c1,  0.0);
            points.push_back(p);
            p = Point( 0.0,   c2,   c1);
            points.push_back(p);
            p = Point( 0.0,   c2,  -c1);
            points.push_back(p);
            p = Point( 0.0,  -c2,   c1);
            points.push_back(p);
            p = Point( 0.0,  -c2,  -c1);
            points.push_back(p);
            p = Point( 1.5,  1.5,  1.5);
            points.push_back(p);
            p = Point( 1.5,  1.5, -1.5);
            points.push_back(p);
            p = Point( 1.5, -1.5,  1.5);
            points.push_back(p);
            p = Point( 1.5, -1.5, -1.5);
            points.push_back(p);
            p = Point(-1.5,  1.5,  1.5);
            points.push_back(p);
            p = Point(-1.5,  1.5, -1.5);
            points.push_back(p);
            p = Point(-1.5, -1.5,  1.5);
            points.push_back(p);
            p = Point(-1.5, -1.5, -1.5);
            points.push_back(p);

   // edges
Edge e = Edge( 12,  0);  edges.push_back(e);
e = Edge( 12,  2);  edges.push_back(e);
e = Edge( 12, 26);  edges.push_back(e);
e = Edge( 12,  4);  edges.push_back(e);
e = Edge( 12, 24);  edges.push_back(e);
e = Edge( 13,  3);  edges.push_back(e);
e = Edge( 13,  1);  edges.push_back(e);
e = Edge( 13, 25);  edges.push_back(e);
e = Edge( 13,  5);  edges.push_back(e);
e = Edge( 13, 27);  edges.push_back(e);
e = Edge( 14,  2);  edges.push_back(e);
e = Edge( 14,  0);  edges.push_back(e);
e = Edge( 14, 28);  edges.push_back(e);
e = Edge( 14,  6);  edges.push_back(e);
e = Edge( 14, 30);  edges.push_back(e);
e = Edge( 15,  1);  edges.push_back(e);
e = Edge( 15,  3);  edges.push_back(e);
e = Edge( 15, 31);  edges.push_back(e);
e = Edge( 15,  7);  edges.push_back(e);
e = Edge( 15, 29);  edges.push_back(e);
e = Edge( 16,  4);  edges.push_back(e);
e = Edge( 16,  5);  edges.push_back(e);
e = Edge( 16, 25);  edges.push_back(e);
e = Edge( 16,  8);  edges.push_back(e);
e = Edge( 16, 24);  edges.push_back(e);
e = Edge( 17,  5);  edges.push_back(e);
e = Edge( 17,  4);  edges.push_back(e);
e = Edge( 17, 26);  edges.push_back(e);
e = Edge( 17,  9);  edges.push_back(e);
e = Edge( 17, 27);  edges.push_back(e);
e = Edge( 18,  7);  edges.push_back(e);
e = Edge( 18,  6);  edges.push_back(e);
e = Edge( 18, 28);  edges.push_back(e);
e = Edge( 18, 10);  edges.push_back(e);
e = Edge( 18, 29);  edges.push_back(e);
e = Edge( 19,  6);  edges.push_back(e);
e = Edge( 19,  7);  edges.push_back(e);
e = Edge( 19, 31);  edges.push_back(e);
e = Edge( 19, 11);  edges.push_back(e);
e = Edge( 19, 30);  edges.push_back(e);
e = Edge( 20,  8);  edges.push_back(e);
e = Edge( 20, 10);  edges.push_back(e);
e = Edge( 20, 28);  edges.push_back(e);
e = Edge( 20,  0);  edges.push_back(e);
e = Edge( 20, 24);  edges.push_back(e);
e = Edge( 21, 10);  edges.push_back(e);
e = Edge( 21,  8);  edges.push_back(e);
e = Edge( 21, 25);  edges.push_back(e);
e = Edge( 21,  1);  edges.push_back(e);
e = Edge( 21, 29);  edges.push_back(e);
e = Edge( 22, 11);  edges.push_back(e);
e = Edge( 22,  9);  edges.push_back(e);
e = Edge( 22, 26);  edges.push_back(e);
e = Edge( 22,  2);  edges.push_back(e);
e = Edge( 22, 30);  edges.push_back(e);
e = Edge( 23,  9);  edges.push_back(e);
e = Edge( 23, 11);  edges.push_back(e);
e = Edge( 23, 31);  edges.push_back(e);
e = Edge( 23,  3);  edges.push_back(e);
e = Edge( 23, 27);  edges.push_back(e);


e = Edge( 0,  2 ) ; edges.push_back(e);
e = Edge( 2, 26 ) ; edges.push_back(e);
e = Edge(26,  4 ) ; edges.push_back(e);
e = Edge( 4, 24 ) ; edges.push_back(e);
e = Edge(24,  0 ) ; edges.push_back(e);
e = Edge( 3,  1 ) ; edges.push_back(e);
e = Edge( 1, 25 ) ; edges.push_back(e);
e = Edge(25,  5 ) ; edges.push_back(e);
e = Edge( 5, 27 ) ; edges.push_back(e);
e = Edge(27,  3 ) ; edges.push_back(e);
e = Edge( 2,  0 ) ; edges.push_back(e);
e = Edge( 0, 28 ) ; edges.push_back(e);
e = Edge(28,  6 ) ; edges.push_back(e);
e = Edge( 6, 30 ) ; edges.push_back(e);
e = Edge(30,  2 ) ; edges.push_back(e);
e = Edge( 1,  3 ) ; edges.push_back(e);
e = Edge( 3, 31 ) ; edges.push_back(e);
e = Edge(31,  7 ) ; edges.push_back(e);
e = Edge( 7, 29 ) ; edges.push_back(e);
e = Edge(29,  1 ) ; edges.push_back(e);
e = Edge( 4,  5 ) ; edges.push_back(e);
e = Edge( 5, 25 ) ; edges.push_back(e);
e = Edge(25,  8 ) ; edges.push_back(e);
e = Edge( 8, 24 ) ; edges.push_back(e);
e = Edge(24,  4 ) ; edges.push_back(e);
e = Edge( 5,  4 ) ; edges.push_back(e);
e = Edge( 4, 26 ) ; edges.push_back(e);
e = Edge(26,  9 ) ; edges.push_back(e);
e = Edge( 9, 27 ) ; edges.push_back(e);
e = Edge(27,  5 ) ; edges.push_back(e);
e = Edge( 7,  6 ) ; edges.push_back(e);
e = Edge( 6, 28 ) ; edges.push_back(e);
e = Edge(28, 10 ) ; edges.push_back(e);
e = Edge(10, 29 ) ; edges.push_back(e);
e = Edge(29,  7 ) ; edges.push_back(e);
e = Edge( 6,  7 ) ; edges.push_back(e);
e = Edge( 7, 31 ) ; edges.push_back(e);
e = Edge(31, 11 ) ; edges.push_back(e);
e = Edge(11, 30 ) ; edges.push_back(e);
e = Edge(30,  6 ) ; edges.push_back(e);
e = Edge( 8, 10 ) ; edges.push_back(e);
e = Edge(10, 28 ) ; edges.push_back(e);
e = Edge(28,  0 ) ; edges.push_back(e);
e = Edge( 0, 24 ) ; edges.push_back(e);
e = Edge(24,  8 ) ; edges.push_back(e);
e = Edge(10,  8 ) ; edges.push_back(e);
e = Edge( 8, 25 ) ; edges.push_back(e);
e = Edge(25,  1 ) ; edges.push_back(e);
e = Edge( 1, 29 ) ; edges.push_back(e);
e = Edge(29, 10 ) ; edges.push_back(e);
e = Edge(11,  9 ) ; edges.push_back(e);
e = Edge( 9, 26 ) ; edges.push_back(e);
e = Edge(26,  2 ) ; edges.push_back(e);
e = Edge( 2, 30 ) ; edges.push_back(e);
e = Edge(30, 11 ) ; edges.push_back(e);
e = Edge( 9, 11 ) ; edges.push_back(e);
e = Edge(11, 31 ) ; edges.push_back(e);
e = Edge(31,  3 ) ; edges.push_back(e);
e = Edge( 3, 27 ) ; edges.push_back(e);
e = Edge(27,  9 ) ; edges.push_back(e);

}

PentakisDodecahedron::~PentakisDodecahedron()
{
    //dtor
}


void PentakisDodecahedron::draw()
{
  for( int i = 0; i<edges.size() ; i ++ )
  {
        Point p1 = points[edges[i].getA()].projection(4);
        Point p2 = points[edges[i].getB()].projection(4);
        al_draw_line(400 + p1.getX()*50, 300 + p1.getY()* 50, 400 + p2.getX() * 50, 300 + p2.getY() * 50, al_map_rgb(255,255,255),1);
  };

}

