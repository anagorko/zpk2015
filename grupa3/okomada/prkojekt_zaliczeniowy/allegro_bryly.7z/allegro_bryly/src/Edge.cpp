#include "Edge.h"
#include <Point.h>
Edge::Edge()
{
    //ctor
}

Edge::Edge(int _a, int _b)
{
   a = _a;
   b = _b;
}

Edge::~Edge()
{
    //dtor
}
