#include "Object3D.h"

Object3D::Object3D()
{
    //ctor
}

Object3D::~Object3D()
{
    //dtor
}


Point Object3D:: localization()
{
    return points[0];
}
void Object3D:: translate(double x, double y, double z)
{
  double p_x, p_y, p_z;
  for( int i = 0; i< points.size(); i++ )
  {
    p_x = points[i].getX() + x;
    p_y = points[i].getY() + y;
    p_z = points[i].getZ() + z;
    points[i].setX(p_x);
    points[i].setY(p_y);
    points[i].setZ(p_z);
  };
}



void Object3D:: rotateX(double angle)
{
  double p_x, p_y, p_z;
  angle = angle * M_PI / 180.0;
  for( int i = 0; i< points.size(); i++ )
  {
    p_y = points[i].getY()*cos(angle) - points[i].getZ()* sin(angle);
    p_z = points[i].getY()*sin(angle) + points[i].getZ()* cos(angle);

    points[i].setY(p_y);
    points[i].setZ(p_z);
  };
}

void Object3D:: rotateY(double angle)
{
  double p_x, p_y, p_z;
  angle = angle * M_PI / 180.0;
  for( int i = 0; i< points.size(); i++ )
  {
    p_z = points[i].getZ()*cos(angle) - points[i].getX()* sin(angle);
    p_x = points[i].getZ()*sin(angle) + points[i].getX()* cos(angle);

    points[i].setZ(p_z);
    points[i].setX(p_x);
  };
}

void Object3D:: rotateZ(double angle)
{
  double p_x, p_y, p_z;
  angle = angle * M_PI / 180.0;
  for( int i = 0; i< points.size(); i++ )
  {
    p_x = points[i].getX()*cos(angle) - points[i].getY()* sin(angle);
    p_y = points[i].getX()*sin(angle) + points[i].getY()* cos(angle);

    points[i].setX(p_x);
    points[i].setY(p_y);
  };
}

