#include "Point.h"

Point::Point()
{

}
Point::Point(double _x, double _y, double _z)
{
    x = _x;
    y = _y;
    z = _z;
}

Point::~Point()
{
    //dtor
}

Point Point:: projection(float d)
{
    Point p;
    if ((z + d) != 0)
    {
        p.x = x * d/(z + d);
        p.y = y * d/(z + d);
        p.z = 0.0;
    }
    else
    {   p.x = x ;
        p.y = y ;
        p.z = 0.0;
    }
    return p;
}
