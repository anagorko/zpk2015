#ifndef TRUNCATEDICOSIDODECAHEDRON_H
#define TRUNCATEDICOSIDODECAHEDRON_H
#include <Object3D.h>

class TruncatedIcosidodecahedron : public Object3D
{
    public:
        TruncatedIcosidodecahedron();
        virtual ~TruncatedIcosidodecahedron();
        virtual void draw() override;

    protected:

    private:
};

#endif // TRUNCATEDICOSIDODECAHEDRON_H

