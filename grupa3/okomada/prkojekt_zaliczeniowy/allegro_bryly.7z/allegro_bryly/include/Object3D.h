#ifndef OBJECT3D_H
#define OBJECT3D_H
#include <list>
#include <iostream>
#include <vector>
#include <cstddef>
#include <Point.h>
#include <Edge.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <math.h>

using namespace std;


class Object3D
{
    public:
        Object3D();
        virtual ~Object3D();
        virtual void draw() = 0;
         void translate(double x, double y , double z ) ;
         void rotateX(double angle) ;
         void rotateY(double angle) ;
         void rotateZ(double angle) ;
         Point localization() ;

    protected:
        std:: vector <Point> points;
        std:: vector <Edge> edges;

    private:
};

#endif // OBJECT3D_H
