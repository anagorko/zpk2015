#ifndef PENTAKISDODECAHEDRON_H
#define PENTAKISDODECAHEDRON_H
#include <Object3D.h>


class PentakisDodecahedron : public Object3D
{
    public:
        PentakisDodecahedron();
        virtual ~PentakisDodecahedron();
        virtual void draw() override;

    protected:

    private:
};

#endif // PENTAKISDODECAHEDRON_H
