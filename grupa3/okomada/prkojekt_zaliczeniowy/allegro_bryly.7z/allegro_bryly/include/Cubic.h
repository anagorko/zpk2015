#ifndef CUBIC_H
#define CUBIC_H
#include<Object3D.h>

class Cubic : public Object3D
{
    public:
        Cubic();
        virtual ~Cubic();
        virtual void draw() override;

    protected:

    private:
};

#endif // CUBIC_H
