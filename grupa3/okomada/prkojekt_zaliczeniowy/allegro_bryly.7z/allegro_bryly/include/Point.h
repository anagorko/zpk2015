#ifndef POINT_H
#define POINT_H
#include <math.h>
#include <cmath>


class Point
{
private:
	double x;
	double y;
	double z;
public:
    Point();
    Point(double _x, double _y, double _z);
    ~Point();
	void setX(double _x) { x = _x; }
	void setY(double _y) { y = _y; }
	void setZ(double _z) { z = _z; }

	double getX() { return x; }
	double getY() { return y; }
	double getZ() { return z; }

	Point projection(float d);

};

#endif // POINT_H
