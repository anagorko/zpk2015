#ifndef EDGE_H
#define EDGE_H
#include <Point.h>

class Edge
{
    public:
        Edge();
        Edge(int _a, int _b);
        virtual ~Edge();

    void setA(int _a) { a = _a; }
	void setB(int _b) { b = _b; }


	int getA() { return a; }
	int getB() { return b; }


    protected:

    private:
        int a;
        int b;
};

#endif // EDGE_H
